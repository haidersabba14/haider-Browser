# haider Browser 👑

إصدار تأسيسي أصلي **0.2.0** لـ Android وiOS. ليس صفحة ويب داخل ملف تثبيت: Android يستخدم Kotlin وAndroid WebView وواجهات Android الأصلية، وiOS يستخدم SwiftUI وWKWebView.

**هذا الإصدار لا يكمل الميزات الـ170.** انظر [FEATURES-AND-TESTS.md](FEATURES-AND-TESTS.md) لحالة كل ميزة والفصل بين الكود المكتوب والاختبار الفعلي.

- Android: الحد الأدنى Android 9 / API 28؛ البناء API 35؛ واجهة أصلية دون Compose.
- iOS: الحد الأدنى iOS 16؛ مشروع Xcode مستقل دون حزم خارجية. يتطلب Mac وXcode والتوقيع للتثبيت المعتاد.
- لا حساب أو قاعدة بيانات سحابية أو سيرفر تابع للمشروع أو تتبع. التصفح يتصل بالمواقع المختارة وبمحرك البحث. تحديث القوائم اختياري ويتصل بـeasylist.to.
- محرك الحظر يدعم **مجموعة محددة** من صيغة EasyList/EasyPrivacy؛ لا يضمن حظر إعلانات الفيديو أو YouTube.

## المجلدات

```
android/app/src/main/java/com/haider/browser/
  adblock/       محلل القواعد وقرار الحظر
  tabs/          التبويبات والتبويبات المغلقة
  data/          الإعدادات والسجل والمفضلة والتنقل
  downloads/     Android DownloadManager
  privacy/       تشفير الروابط بواسطة Android Keystore
  ui/            نشاط عام ونشاط خاص في عملية منفصلة
android/app/src/test/         اختبارات المنطق
android/app/src/androidTest/  اختبار WebView الفعلي

ios/HaiderBrowser.xcodeproj/  مشروع Xcode + scheme مشترك
ios/HaiderBrowser/
  Browser/       WKWebView والتبويبات والتنزيلات
  AdBlock/       مترجم WKContentRuleListStore
  Data/          البيانات المحلية
  Privacy/       CryptoKit + Keychain + LocalAuthentication
  UI/            SwiftUI
scripts/         البناء وفحص هيكل iOS وتوليد المشروع والشعار
tests/           خادم محلي لاختبار التطوير فقط
```

تصميم 0.2.0: أيقونات متجهية أصلية، رسم مداري محلي، بحث جديد بالرئيسية، بطاقات حماية ومفضلة، وحوارات وثيم فاتح محسّنان. لا تغييرات على حدود محرك الحظر أو قائمة الميزات المتقدمة. مسار IPA على Mac أو GitHub Actions في [IOS-IPA.md](IOS-IPA.md)؛ لم يُنفَّذ بناء iOS هنا.

تعليمات البناء والتثبيت: [INSTALL.md](INSTALL.md). التفاصيل الأمنية: [docs/SECURITY.md](docs/SECURITY.md).

لا يعتمد تشغيل التطبيق على أي من أدوات الاختبار أو الخادم المحلي الموجود في tests.
