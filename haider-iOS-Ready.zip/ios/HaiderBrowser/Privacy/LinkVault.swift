import Foundation
import CryptoKit
import Security
import LocalAuthentication

enum LinkVault {
    private static func key() throws -> SymmetricKey {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: "com.haider.browser.vault", kSecAttrAccount as String: "key"]
        var result: CFTypeRef?
        let status = SecItemCopyMatching(query.merging([kSecReturnData as String: true]) { _, new in new } as CFDictionary, &result)
        if status == errSecSuccess, let data = result as? Data { return SymmetricKey(data: data) }
        guard status == errSecItemNotFound else { throw NSError(domain: NSOSStatusErrorDomain, code: Int(status)) }
        let new = SymmetricKey(size: .bits256); let data = new.withUnsafeBytes { Data($0) }
        var attributes = query
        attributes[kSecValueData as String] = data
        attributes[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        let added = SecItemAdd(attributes as CFDictionary, nil)
        guard added == errSecSuccess else { throw NSError(domain: NSOSStatusErrorDomain, code: Int(added)) }
        return new
    }
    private static var location: URL { FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("links.vault") }
    static func read() throws -> String { guard FileManager.default.fileExists(atPath: location.path) else { return "" }; let box = try AES.GCM.SealedBox(combined: Data(contentsOf: location)); return String(decoding: try AES.GCM.open(box, using: key()), as: UTF8.self) }
    static func save(_ text: String) throws {
        let data = try AES.GCM.seal(Data(text.utf8), using: key()).combined!
        try FileManager.default.createDirectory(at: location.deletingLastPathComponent(), withIntermediateDirectories: true)
        try data.write(to: location, options: [.atomic, .completeFileProtection])
        var values = URLResourceValues(); values.isExcludedFromBackup = true; var url = location; try url.setResourceValues(values)
    }
    static func authenticate(reason: String) async throws -> Bool { try await LAContext().evaluatePolicy(.deviceOwnerAuthentication, localizedReason: reason) }
}
