# Third-party notices

Original application code and the original small domain starter list: MIT, see ../LICENSE.

- Kotlin standard library 2.0.21: JetBrains, Apache License 2.0.
- ZXing core 3.5.3 (QR generation): ZXing authors, Apache License 2.0, https://github.com/zxing/zxing.
- Android Gradle Plugin / Gradle wrapper and AndroidX test tools: upstream Apache License 2.0 and related notices. Test tools are not shipped as app runtime components.
- JUnit 4.13.2: EPL 1.0, test only.
- Android WebView and Apple WebKit are system components under their respective platform licenses. No custom browser engine is bundled.
- EasyList / EasyPrivacy are not bundled in full or redistributed in this source. Downloading is an explicit user action from https://easylist.to. Their upstream licenses and subscription terms apply; review them before redistributing downloaded lists. No claim of affiliation is made.
- Logo generated originally from vector geometry in scripts/generate_icons.py. No external photographs or trademarks are used.

See Apache-2.0.txt for the Apache license text. The APK carries Gradle-generated META-INF dependency notices where supplied by upstream artifacts.
