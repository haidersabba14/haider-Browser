package com.haider.browser.data

import java.net.URI
import java.net.URLEncoder

object Navigation {
    fun resolve(input: String, engine: String = "DuckDuckGo"): String? {
        val v = input.trim()
        if (v.isEmpty()) return null
        val scheme = Regex("^[a-zA-Z][a-zA-Z0-9+.-]*:").find(v)?.value?.lowercase()
        if (scheme != null)
            return if (
                scheme in listOf("http:", "https:") &&
                    runCatching { URI(v).host != null }.getOrDefault(false)
            )
                v
            else null
        if (!v.contains(' ') && (v.contains('.') || v.startsWith("localhost"))) return "https://$v"
        val base =
            when (engine) {
                "Google" -> "https://www.google.com/search?q="
                "Bing" -> "https://www.bing.com/search?q="
                else -> "https://duckduckgo.com/?q="
            }
        return base + URLEncoder.encode(v, "UTF-8")
    }
}
