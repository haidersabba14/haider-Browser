import SwiftUI
import WebKit
struct SettingsView: View {
    @ObservedObject var model: BrowserModel
    @Binding var language: String
    @Binding var light: Bool
    @Binding var importing: Bool
    var export: () -> Void
    @AppStorage("appLock") private var lock = false
    @AppStorage("engine") private var engine = "DuckDuckGo"
    private var ar: Bool { language == "ar" }
    var body: some View {
        Form {
            Section(ar ? "المظهر واللغة" : "Appearance & language") {
                Toggle(ar ? "المظهر الفاتح" : "Light theme", isOn: $light)
                Picker("Language / اللغة", selection: $language) { Text("English").tag("en"); Text("العربية").tag("ar") }
                Picker(ar ? "محرك البحث" : "Search engine", selection: $engine) { ForEach(["DuckDuckGo", "Google", "Bing"], id: \.self) { Text($0) } }
            }
            Section(ar ? "الأمان" : "Security") { Toggle(ar ? "قفل التطبيق عند العودة" : "Lock app on return", isOn: $lock); Text(ar ? "يتطلب رمز جهاز أو Face ID أو Touch ID مسجلًا." : "Requires an enrolled device passcode, Face ID or Touch ID.").font(.caption) }
            Section(ar ? "البيانات المحلية" : "Local data") { Button(ar ? "تصدير المفضلة" : "Export bookmarks", action: export); Button(ar ? "استيراد المفضلة (استبدال الحالية)" : "Import bookmarks (replaces existing)") { importing = true } }
            Section("haider Browser 0.2.0") { Text(ar ? "WebKit أصلي • دون حساب أو تتبع\nتُحفظ البيانات محليًا. راجع تقرير الميزات لمعرفة حدود الإصدار." : "Native WebKit • No account or telemetry\nLocal data. See the feature report for release limitations.") }
        }
    }
}
struct ProtectionView: View {
    @ObservedObject var model: BrowserModel
    let ar: Bool
    @AppStorage("block") private var enabled = true
    @AppStorage("strong") private var strong = false
    @AppStorage("customRules") private var custom = ""
    @State private var exceptions: [String] = UserDefaults.standard.stringArray(forKey: "whitelist") ?? []
    var body: some View {
        Form {
            Toggle(ar ? "تفعيل مانع الإعلانات" : "Enable AdBlock", isOn: $enabled).onChange(of: enabled) { _ in Task { await model.rebuildRules(); model.current?.web.reload() } }
            Toggle(ar ? "إخفاء عناصر إضافية" : "Strong cosmetic mode", isOn: $strong).onChange(of: strong) { _ in Task { await model.rebuildRules(); model.current?.web.reload() } }
            Text(ar ? "عدد الطلبات المحظورة: غير متاح من WebKit." : "Blocked request count: not exposed by WebKit.")
            Section(ar ? "المواقع المستثناة" : "Site exceptions") {
                if let host = model.current?.web.url?.host { Button((ar ? "تبديل الاستثناء: " : "Toggle exception: ") + host) { if exceptions.contains(host) { exceptions.removeAll { $0 == host } } else { exceptions.append(host) }; UserDefaults.standard.set(exceptions, forKey: "whitelist"); Task { await model.rebuildRules(); model.current?.web.reload() } } }
                ForEach(exceptions, id: \.self) { Text($0) }.onDelete { offsets in exceptions.remove(atOffsets: offsets); UserDefaults.standard.set(exceptions, forKey: "whitelist"); Task { await model.rebuildRules() } }
            }
            Section(ar ? "قواعد مخصصة" : "Custom rules") { TextEditor(text: $custom).frame(minHeight: 130).font(.system(.caption, design: .monospaced)); Button(ar ? "تطبيق القواعد" : "Apply rules") { Task { await model.rebuildRules(); model.current?.web.reload() } } }
            Section(ar ? "قوائم الفلاتر" : "Filter lists") {
                Button(ar ? "تنزيل EasyList وEasyPrivacy" : "Download EasyList & EasyPrivacy") { Task { await model.updateFilters() } }
                Text(ar ? "يدعم مجموعة محددة من قواعد النطاقات والاستثناءات و## العامة. غير المدعوم: \(model.unsupported)" : "Supports domain rules, exceptions, third-party and generic ## selectors. Unsupported: \(model.unsupported)")
                Text(ar ? "قائمة بداية صغيرة مضمّنة. التحديث اختياري ويتصل بموقع easylist.to العام. لا يمكن ضمان حظر إعلانات الفيديو." : "Small starter list bundled. Optional updates contact public easylist.to. Video ad blocking is not guaranteed.").font(.caption)
            }
        }
    }
}
struct LibraryView: View {
    @ObservedObject var store: LocalStore
    let kind: String
    @ObservedObject var model: BrowserModel
    @State private var search = ""
    private var items: [SavedLink] { (kind == "bookmarks" ? store.bookmarks : kind == "notes" ? store.notes : store.history).filter { search.isEmpty || $0.title.localizedCaseInsensitiveContains(search) || $0.url.localizedCaseInsensitiveContains(search) } }
    var body: some View { List { ForEach(items) { item in if kind == "notes" { Text(item.url).textSelection(.enabled) } else { Button { model.navigate(item.url) } label: { VStack(alignment: .leading) { Text(item.title); Text(item.url).font(.caption).foregroundStyle(.secondary).lineLimit(1) } } } }.onDelete { offsets in let ids = offsets.map { items[$0].id }; if kind == "bookmarks" { store.bookmarks.removeAll { ids.contains($0.id) } } else if kind == "notes" { store.notes.removeAll { ids.contains($0.id) } } else { store.history.removeAll { ids.contains($0.id) } } } }.searchable(text: $search) }
}
struct DownloadsView: View {
    let ar: Bool
    @State private var files: [URL] = []
    @State private var share: URL?
    @State private var search = ""
    private var visible: [URL] { files.filter { search.isEmpty || $0.lastPathComponent.localizedCaseInsensitiveContains(search) } }
    var body: some View {
        List { if files.isEmpty { Text(ar ? "لا توجد تنزيلات. تُحفَظ الملفات المدعومة هنا." : "No downloads. Supported downloaded files appear here.") }; ForEach(visible, id: \.self) { url in ShareLink(item: url) { VStack(alignment: .leading) { Text(url.lastPathComponent); Text(ByteCountFormatter.string(fromByteCount: Int64((try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0), countStyle: .file)).font(.caption) } } }.onDelete { offsets in for i in offsets { try? FileManager.default.removeItem(at: visible[i]) }; refresh() } }.searchable(text: $search).onAppear(perform: refresh)
    }
    private func refresh() { let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("Downloads"); files = (try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: [.fileSizeKey])) ?? [] }
}
