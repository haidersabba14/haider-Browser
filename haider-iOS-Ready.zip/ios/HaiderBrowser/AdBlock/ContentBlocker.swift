import Foundation
import WebKit

/// Bounded ABP subset, translated to Apple's declarative content rules.
enum ContentBlocker {
    static let seed = """
    ||doubleclick.net^
    ||googlesyndication.com^
    ||googleadservices.com^
    ||google-analytics.com^
    ||googletagmanager.com^
    ||connect.facebook.net^
    ||ads.twitter.com^
    ||adsystem.amazon.com^
    ||adnxs.com^
    ||adsrvr.org^
    ||scorecardresearch.com^
    ||taboola.com^
    ||outbrain.com^
    ##.adsbygoogle
    ##[data-ad-slot]
    """
    struct Result { let json: String; let unsupported: Int }
    static func translate(_ text: String, strong: Bool, whitelist: [String]) throws -> Result {
        var blocking = [[String: Any]](), exceptions = [[String: Any]](), skipped = 0
        let regex = try NSRegularExpression(pattern: #"^(@@)?\|\|([a-zA-Z0-9.-]+)\^(?:\$(third-party))?$"#)
        let css = try NSRegularExpression(pattern: #"^[a-zA-Z0-9_ .#\[\]='"^*|:()\-]+$"#)
        for raw in text.split(separator: "\n").prefix(200000) {
            let line = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            if line.isEmpty || line.hasPrefix("!") || line.hasPrefix("[") { continue }
            if line.hasPrefix("##") {
                let selector = String(line.dropFirst(2))
                if css.firstMatch(in: selector, range: NSRange(selector.startIndex..., in: selector)) != nil && !selector.contains(":has") && !selector.contains(":style") {
                    blocking.append(["trigger": ["url-filter": ".*"], "action": ["type": "css-display-none", "selector": selector]])
                } else { skipped += 1 }
                continue
            }
            let ns = line as NSString
            guard let m = regex.firstMatch(in: line, range: NSRange(location: 0, length: ns.length)) else { skipped += 1; continue }
            let host = ns.substring(with: m.range(at: 2)).lowercased()
            guard host.contains("."), !host.hasPrefix(".") else { skipped += 1; continue }
            // Use the ASCII subset supported by WebKit's regular expression compiler.
            let domain = host.replacingOccurrences(of: ".", with: "\\.")
            var trigger: [String: Any] = ["url-filter": "^https?://([^/]+\\.)?" + domain + "[:/]"]
            if m.range(at: 3).location != NSNotFound { trigger["load-type"] = ["third-party"] }
            let allow = m.range(at: 1).location != NSNotFound
            let entry: [String: Any] = ["trigger": trigger, "action": ["type": allow ? "ignore-previous-rules" : "block"]]
            if allow { exceptions.append(entry) } else { blocking.append(entry) }
        }
        if strong { blocking.append(["trigger": ["url-filter": ".*"], "action": ["type": "css-display-none", "selector": "[id^='google_ads_'],[data-ad-slot],ins.adsbygoogle"]]) }
        blocking += exceptions
        if !whitelist.isEmpty { blocking.append(["trigger": ["url-filter": ".*", "if-domain": whitelist.map { "*" + $0 }], "action": ["type": "ignore-previous-rules"]]) }
        if blocking.isEmpty { blocking.append(["trigger": ["url-filter": "^https?://haider-invalid\\.invalid/"], "action": ["type": "block"]]) }
        let data = try JSONSerialization.data(withJSONObject: blocking)
        return Result(json: String(decoding: data, as: UTF8.self), unsupported: skipped)
    }
    static func compile(text: String, strong: Bool, whitelist: [String]) async throws -> (WKContentRuleList, Int) {
        let result = try translate(text, strong: strong, whitelist: whitelist)
        return try await withCheckedThrowingContinuation { continuation in
            WKContentRuleListStore.default().compileContentRuleList(forIdentifier: "haider.rules", encodedContentRuleList: result.json) { list, error in
                if let list { continuation.resume(returning: (list, result.unsupported)) }
                else { continuation.resume(throwing: error ?? NSError(domain: "ContentBlocker", code: 1)) }
            }
        }
    }
}
