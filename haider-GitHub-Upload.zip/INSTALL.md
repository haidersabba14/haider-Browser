# تثبيت وبناء haider Browser 0.2.0

## Android — APK حقيقي

المتطلبات: Android 9 أو أحدث، WebView نظام محدث. ملف `haider-Browser.apk` نسخة Release موقعة بمفتاح خاص أُنشئ لهذا المشروع؛ ليست توقيع Google Play ولا ملفًا فارغًا.

1. انقل APK إلى الجهاز وافتحه.
2. اسمح لتطبيق الملفات الذي فتحته بتثبيت التطبيقات من هذا المصدر عند طلب النظام.
3. ثبّت التطبيق. لا يحتاج أذونات تخزين شاملة أو كاميرا أو ميكروفون أو موقع.
4. إذا أردت التحديث لاحقًا، احتفظ بمفتاح التوقيع نفسه؛ التوقيع المختلف يتطلب إلغاء تثبيت النسخة السابقة وفقدان بياناتها.

### البناء محليًا

ثبّت JDK 17 أو 21 وAndroid SDK Platform 35 وBuild Tools 35.0.0 وPlatform Tools. ملفات Gradle Wrapper مضمّنة بإصدار 8.9. الإنترنت مطلوب في البناء الأول لتنزيل أدوات ومكتبات التطوير المجانية.

```bash
export ANDROID_HOME="$HOME/Android/Sdk"
cd android
printf 'sdk.dir=%s\n' "$ANDROID_HOME" > local.properties
./gradlew testDebugUnitTest lintDebug assembleDebug assembleRelease
```

يخرج APK تجريبي موقّع للتطوير في `app/build/outputs/apk/debug/app-debug.apk` وRelease غير موقّع في `app/build/outputs/apk/release/app-release-unsigned.apk`.

لتوقيع Release بمفتاحك:

```bash
keytool -genkeypair -keystore /secure/haider.jks -alias haider \
  -keyalg RSA -keysize 3072 -validity 10000
# أدخل كلمة المرور تفاعليًا ثم استخدم البيئة؛ لا تضعها في git.
export HAIDER_KEYSTORE=/secure/haider.jks
export HAIDER_KEY_ALIAS=haider
read -rs -p 'Keystore password: ' HAIDER_STORE_PASSWORD
export HAIDER_STORE_PASSWORD
cd ..
./scripts/build-android.sh
```

الناتج: `dist/haider-Browser.apk`. لفقدان مفتاح التوقيع أثر دائم على إمكانية ترقية التطبيق. نسخة المفتاح الخاصة بالملف المسلم محفوظة منفصلة عن المصدر في `haider-Signing-Backup.zip`؛ تحتوي على سر التوقيع وكلمة مروره، فاحفظها خارج المستودع ولا تنشرها.

### إعادة الاختبار على جهاز أو محاكي

الاختبار يغيّر بيانات التطبيق في نسخة الاختبار، لذا استخدم جهاز تطوير:

```bash
python3 tests/fixture_server.py
# في نافذة أخرى، من android/؛ الاختبار يستخدم localhost عبر adb reverse للوصول للمضيف.
adb reverse tcp:8787 tcp:8787
./gradlew connectedDebugAndroidTest
```

لا يحتاج التصفح العادي لهذا الخادم. اختبارات القياسات الحيوية وDRM وPiP والتوافق مع مواقع متعددة تتطلب أجهزة فعلية.

## iOS — مشروع Xcode، لا يوجد IPA مبني في التسليم الحالي

بيئة التنفيذ Linux: لا macOS ولا Xcode ولا Apple SDK ولا هوية توقيع Apple. لذلك **لم يُنتج IPA ولم يُختبر تطبيق iOS على جهاز أو محاكي**. المشروع الكامل موجود في `ios/HaiderBrowser.xcodeproj`، وليس ملفات HTML مغلّفة.

المتطلبات المتبقية:

1. Mac مع Xcode 16 أو إصدار أحدث متوافق وiOS SDK؛ الحد الأدنى للتطبيق iOS 16.
2. افتح `ios/HaiderBrowser.xcodeproj` واختر scheme `haider Browser`.
3. اضبط Bundle Identifier فريدًا وDevelopment Team في Signing & Capabilities؛ فعّل Automatic signing، واختر iPhone متصلًا أو محاكيًا.
4. نفّذ Build وRun، وعالج أي أخطاء type-check أو API يكشفها Xcode؛ الفحص المنفذ هنا هو صياغة وهيكل فقط.
5. شغّل اختبارات القبول في التقرير على iPhone قبل الاعتماد على الخصوصية أو الخزنة أو التنزيلات.

التثبيت المباشر من Xcode بحساب Apple شخصي قد يكون مجانيًا مع قيود Apple وانتهاء صلاحية قصير. توزيع Ad Hoc أو App Store قد يتطلب عضوية Apple المدفوعة؛ ليس هذا اشتراكًا لتشغيل المتصفح، لكنه ليس مشمولًا في هدف صفر تكلفة التوزيع.

لإنشاء IPA مُوقّع بالطريقة الرسمية، اضبط خيارات التصدير المطابقة لفريقك وأجهزتك وملفات provisioning:

```bash
export HAIDER_TEAM_ID=YOUR_TEAM_ID
export HAIDER_EXPORT_OPTIONS=/absolute/path/to/ExportOptions.plist
./scripts/build-ios.sh
```

الناتج عند نجاح البناء والتصدير: `dist/haider-Browser.ipa`، ويحتوي على تطبيق Mach-O حقيقي.

لبناء حزمة غير موقّعة من تطبيق iOS فعلي على Mac:

```bash
./scripts/build-ios.sh --unsigned
```

الناتج: `dist/haider-Browser-unsigned.ipa`. لا تُثبت الحزمة غير الموقّعة بالطريقة الرسمية مباشرة. يمكن فقط بحث مسار توقيع/تثبيت متوافق مع الجهاز. **لا يوجد تكامل TrollStore مُختبَر أو ضمان توافق معه**؛ دعم الجهاز وإصدار iOS شرط خارجي، ولا يضم المشروع استغلالًا أو تجاوزًا لقيود النظام أو استحقاقات خاصة.

## البيانات وحدود الاستخدام

- الإشارات والسجل والملاحظات والإعدادات محلية؛ ليست كلها مشفرة. خزنة الروابط وحدها مشفرة بمفتاح النظام. لا يوجد مدير كلمات مرور في هذا الإصدار.
- ملفات التنزيل العادية دائمة. تنزيل الملفات وتخزين المفضلة والملاحظات الخاصة معطّل على Android؛ iOS يعطّل تنزيلات التبويبات الخاصة.
- Android: جلسة خاصة معزولة عن الجلسة العامة في عملية وWebView data directory منفصلين. عند الإغلاق العادي تُمسح بياناتها وتُنهى العملية؛ إذا قتل النظام العملية، تنظَّف البيانات المتبقية عند بدء الجلسة الخاصة التالية. هذا ليس ضمانًا لمحو جنائي من الفلاش.
- iOS: تخزين WebKit غير دائم للتبويبات الخاصة؛ لا تُحفظ روابطها في الجلسة والسجل. إغلاق جميع التبويبات الخاصة يزيل مراجع WebView الخاصة.
- الاستيراد يستبدل المفضلة الحالية. صيغ النسخ بين المنصتين مختلفة حاليًا، ولا توجد مزامنة.
- حذف التطبيق يحذف بياناته المحلية؛ تصدير المفضلة لا يصدّر مفتاح الخزنة.
