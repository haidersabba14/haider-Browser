#!/usr/bin/env python3
"""Regenerate the checked-in, dependency-free Xcode project."""
from pathlib import Path
import hashlib
root=Path(__file__).resolve().parents[1]/'ios'
project=root/'HaiderBrowser.xcodeproj'
(project/'xcshareddata/xcschemes').mkdir(parents=True,exist_ok=True)
def uid(s): return hashlib.sha256(s.encode()).hexdigest()[:24].upper()
def q(s): return '"'+s.replace('"','\\"')+'"'
objects=[]
def obj(name,body):
 i=uid(name); objects.append(f'{i} = {{ {body} }};'); return i
swift=sorted((root/'HaiderBrowser').rglob('*.swift'))
refs=[]; sources=[]; resources=[]
for f in swift+list(root.glob('HaiderBrowser/*.xcprivacy'))+[root/'HaiderBrowser/Assets.xcassets']:
 path=f.relative_to(root).as_posix(); typ='sourcecode.swift' if f.suffix=='.swift' else 'folder.assetcatalog' if f.suffix=='.xcassets' else 'text.xml'
 ref=obj(path,f'isa = PBXFileReference; lastKnownFileType = {typ}; path = {q(path)}; sourceTree = "<group>";'); refs.append(ref)
 build=obj(path+'build',f'isa = PBXBuildFile; fileRef = {ref};')
 (sources if f.suffix=='.swift' else resources).append(build)
product=obj('product','isa = PBXFileReference; explicitFileType = wrapper.application; includeInIndex = 0; path = "haider Browser.app"; sourceTree = BUILT_PRODUCTS_DIR;')
products=obj('products',f'isa = PBXGroup; children = ({product},); name = Products; sourceTree = "<group>";')
group=obj('group','isa = PBXGroup; children = ('+','.join(refs+[products])+',); sourceTree = "<group>";')
sourcephase=obj('sources','isa = PBXSourcesBuildPhase; buildActionMask = 2147483647; files = ('+','.join(sources)+',); runOnlyForDeploymentPostprocessing = 0;')
resourcephase=obj('resources','isa = PBXResourcesBuildPhase; buildActionMask = 2147483647; files = ('+','.join(resources)+',); runOnlyForDeploymentPostprocessing = 0;')
frameworks=obj('frameworks','isa = PBXFrameworksBuildPhase; buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0;')
configs={}
for target in ('project','app'):
 ids=[]
 for mode in ('Debug','Release'):
  settings={'SDKROOT':'iphoneos','IPHONEOS_DEPLOYMENT_TARGET':'16.0','SWIFT_VERSION':'5.0','CLANG_ENABLE_MODULES':'YES','CLANG_ENABLE_OBJC_ARC':'YES'}
  if target=='app':settings.update({'PRODUCT_NAME':'haider Browser','PRODUCT_BUNDLE_IDENTIFIER':'com.haider.browser','INFOPLIST_FILE':'HaiderBrowser/Info.plist','ASSETCATALOG_COMPILER_APPICON_NAME':'AppIcon','TARGETED_DEVICE_FAMILY':'1,2','CODE_SIGN_STYLE':'Automatic','CURRENT_PROJECT_VERSION':'2','MARKETING_VERSION':'0.2.0','GENERATE_INFOPLIST_FILE':'NO','SWIFT_EMIT_LOC_STRINGS':'YES'})
  if mode=='Debug':settings.update({'SWIFT_OPTIMIZATION_LEVEL':'-Onone','GCC_PREPROCESSOR_DEFINITIONS':'DEBUG=1','DEBUG_INFORMATION_FORMAT':'dwarf'})
  else:settings.update({'SWIFT_OPTIMIZATION_LEVEL':'-O','DEBUG_INFORMATION_FORMAT':'dwarf-with-dsym','VALIDATE_PRODUCT':'YES'})
  ids.append(obj(target+mode,'isa = XCBuildConfiguration; buildSettings = {'+' '.join(f'{k} = {q(v)};' for k,v in settings.items())+f'}}; name = {mode};'))
 configs[target]=obj(target+'configs','isa = XCConfigurationList; buildConfigurations = ('+','.join(ids)+',); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release;')
target=obj('target',f'isa = PBXNativeTarget; buildConfigurationList = {configs["app"]}; buildPhases = ({sourcephase},{frameworks},{resourcephase},); buildRules = (); dependencies = (); name = "haider Browser"; productName = "haider Browser"; productReference = {product}; productType = "com.apple.product-type.application";')
proj=obj('project',f'isa = PBXProject; attributes = {{ LastUpgradeCheck = 1600; TargetAttributes = {{ {target} = {{ CreatedOnToolsVersion = 16.0; }}; }}; }}; buildConfigurationList = {configs["project"]}; compatibilityVersion = "Xcode 14.0"; developmentRegion = en; hasScannedForEncodings = 0; knownRegions = (en,ar,Base,); mainGroup = {group}; productRefGroup = {products}; projectDirPath = ""; projectRoot = ""; targets = ({target},);')
(project/'project.pbxproj').write_text('// !$*UTF8*$!\n{ archiveVersion = 1; classes = {}; objectVersion = 56; objects = {\n'+'\n'.join(objects)+f'\n}}; rootObject = {proj}; }}\n')
(project/'xcshareddata/xcschemes/haider Browser.xcscheme').write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1600" version="1.3"><BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="haider Browser.app" BlueprintName="haider Browser" ReferencedContainer="container:HaiderBrowser.xcodeproj"/></BuildActionEntry></BuildActionEntries></BuildAction><LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" debugServiceExtension="internal" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="haider Browser.app" BlueprintName="haider Browser" ReferencedContainer="container:HaiderBrowser.xcodeproj"/></BuildableProductRunnable></LaunchAction><ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" savedToolIdentifier="" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES"/><AnalyzeAction buildConfiguration="Debug"/><ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/></Scheme>''')
print(project)
