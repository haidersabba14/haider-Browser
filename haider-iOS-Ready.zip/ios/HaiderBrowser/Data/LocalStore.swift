import Foundation
struct SavedLink: Codable, Identifiable {
    var id = UUID()
    var title: String
    var url: String
    var date = Date()
}
@MainActor final class LocalStore: ObservableObject {
    @Published var bookmarks: [SavedLink] = [] { didSet { save(bookmarks, key: "bookmarks") } }
    @Published var history: [SavedLink] = [] { didSet { save(history, key: "history") } }
    @Published var notes: [SavedLink] = [] { didSet { save(notes, key: "notes") } }
    init() {
        bookmarks = load("bookmarks"); history = load("history"); notes = load("notes")
    }
    private func load(_ key: String) -> [SavedLink] { guard let data = UserDefaults.standard.data(forKey: key) else { return [] }; return (try? JSONDecoder().decode([SavedLink].self, from: data)) ?? [] }
    private func save(_ items: [SavedLink], key: String) { UserDefaults.standard.set(try? JSONEncoder().encode(items), forKey: key) }
    func record(title: String, url: String) { history.removeAll { $0.url == url }; history.insert(SavedLink(title: title, url: url), at: 0); history = Array(history.prefix(1000)) }
}
enum Navigation {
    static func resolve(_ text: String, engine: String) -> URL? {
        let value = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return nil }
        if let components = URLComponents(string: value), let scheme = components.scheme {
            guard ["http", "https"].contains(scheme.lowercased()), components.host?.isEmpty == false else { return nil }; return components.url
        }
        if !value.contains(" ") && value.contains(".") { return URL(string: "https://" + value) }
        let base = engine == "Google" ? "https://www.google.com/search" : engine == "Bing" ? "https://www.bing.com/search" : "https://duckduckgo.com/"
        var components = URLComponents(string: base)!; components.queryItems = [URLQueryItem(name: "q", value: value)]; return components.url
    }
}
