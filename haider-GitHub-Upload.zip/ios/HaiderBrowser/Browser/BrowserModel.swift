import SwiftUI
import WebKit
import UniformTypeIdentifiers

@MainActor final class BrowserTab: NSObject, ObservableObject, Identifiable, WKNavigationDelegate, WKUIDelegate, WKDownloadDelegate {
    let id = UUID()
    let web: WKWebView
    let isPrivate: Bool
    @Published var url = ""
    @Published var title = "haider Browser"
    @Published var loading = false
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var home = true
    weak var model: BrowserModel?
    private var downloadNames: [ObjectIdentifier: URL] = [:]
    init(privateMode: Bool, ruleList: WKContentRuleList?, model: BrowserModel) {
        isPrivate = privateMode; self.model = model
        let config = WKWebViewConfiguration()
        config.websiteDataStore = privateMode ? .nonPersistent() : .default()
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        config.allowsInlineMediaPlayback = true
        config.allowsPictureInPictureMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = .all
        if let ruleList { config.userContentController.add(ruleList) }
        web = WKWebView(frame: .zero, configuration: config)
        super.init()
        web.navigationDelegate = self; web.uiDelegate = self
        web.allowsBackForwardNavigationGestures = true
        web.isOpaque = false; web.backgroundColor = .black
    }
    func load(_ target: URL) { home = false; url = target.absoluteString; web.load(URLRequest(url: target)); model?.persist() }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) { loading = true }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        loading = false; url = webView.url?.absoluteString ?? url; title = webView.title ?? url
        canGoBack = webView.canGoBack; canGoForward = webView.canGoForward
        if !isPrivate { model?.store.record(title: title, url: url) }; model?.persist()
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { loading = false; if (error as NSError).code != NSURLErrorCancelled { model?.message = error.localizedDescription } }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { loading = false; model?.message = error.localizedDescription }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let target = navigationAction.request.url, ["https", "http", "about"].contains(target.scheme?.lowercased() ?? "") else { decisionHandler(.cancel); return }
        if navigationAction.targetFrame == nil { decisionHandler(.cancel); return } // blocks popup windows
        if target.scheme == "http", target.host != webView.url?.host, model?.approvedHTTP != target.host { model?.pendingHTTP = target; decisionHandler(.cancel); return }
        if navigationAction.shouldPerformDownload { decisionHandler(isPrivate ? .cancel : .download) } else { decisionHandler(.allow) }
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        decisionHandler(navigationResponse.canShowMIMEType ? .allow : isPrivate ? .cancel : .download)
    }
    func webView(_ webView: WKWebView, requestMediaCapturePermissionFor origin: WKSecurityOrigin, initiatedByFrame frame: WKFrameInfo, type: WKMediaCaptureType, decisionHandler: @escaping (WKPermissionDecision) -> Void) { decisionHandler(.deny) }
    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) { download.delegate = self }
    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) { download.delegate = self }
    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse, suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("Downloads")
        do {
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            let safe = URL(fileURLWithPath: suggestedFilename).lastPathComponent
            let path = dir.appendingPathComponent(String(UUID().uuidString.prefix(8)) + "-" + (safe.isEmpty ? "download" : safe))
            downloadNames[ObjectIdentifier(download)] = path; completionHandler(path)
        } catch { model?.message = error.localizedDescription; completionHandler(nil) }
    }
    func downloadDidFinish(_ download: WKDownload) { if let path = downloadNames.removeValue(forKey: ObjectIdentifier(download)) { model?.message = "Downloaded: " + path.lastPathComponent } }
    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) { if let path = downloadNames.removeValue(forKey: ObjectIdentifier(download)) { try? FileManager.default.removeItem(at: path) }; model?.message = error.localizedDescription }
}

@MainActor final class BrowserModel: ObservableObject {
    @Published var tabs: [BrowserTab] = []
    @Published var selected: UUID?
    @Published var ready = false
    @Published var message: String?
    @Published var pendingHTTP: URL?
    @Published var unsupported = 0
    var approvedHTTP: String?
    var closed: [String] = []
    let store = LocalStore()
    private var ruleList: WKContentRuleList?
    var current: BrowserTab? { tabs.first { $0.id == selected } }
    var filterURL: URL { FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("filters.txt") }
    init() { Task { await prepare() } }
    func prepare() async {
        await rebuildRules()
        ready = true
        let urls = UserDefaults.standard.stringArray(forKey: "session") ?? []
        for value in urls.prefix(20) { if let url = Navigation.resolve(value, engine: "DuckDuckGo") { newTab(url: url) } }
        if tabs.isEmpty { newTab() }
    }
    func rebuildRules() async {
        guard UserDefaults.standard.object(forKey: "block") as? Bool != false else {
            ruleList = nil; tabs.forEach { $0.web.configuration.userContentController.removeAllContentRuleLists() }; return
        }
        do {
            let cached = (try? String(contentsOf: filterURL, encoding: .utf8)) ?? ""
            let custom = UserDefaults.standard.string(forKey: "customRules") ?? ""
            let result = try await ContentBlocker.compile(text: ContentBlocker.seed + "\n" + cached + "\n" + custom, strong: UserDefaults.standard.bool(forKey: "strong"), whitelist: UserDefaults.standard.stringArray(forKey: "whitelist") ?? [])
            ruleList = result.0; unsupported = result.1
            for tab in tabs { let controller = tab.web.configuration.userContentController; controller.removeAllContentRuleLists(); controller.add(result.0) }
        } catch { message = "Content blocker: " + error.localizedDescription }
    }
    func updateFilters() async {
        do {
            var joined = ""
            for value in ["https://easylist.to/easylist/easylist.txt", "https://easylist.to/easylist/easyprivacy.txt"] {
                var request = URLRequest(url: URL(string: value)!); request.timeoutInterval = 25
                let (data, response) = try await URLSession.shared.data(for: request)
                guard (response as? HTTPURLResponse)?.statusCode == 200, data.count <= 8 * 1024 * 1024 else { throw URLError(.badServerResponse) }
                joined += String(decoding: data, as: UTF8.self) + "\n"
            }
            try FileManager.default.createDirectory(at: filterURL.deletingLastPathComponent(), withIntermediateDirectories: true)
            try joined.write(to: filterURL, atomically: true, encoding: .utf8); await rebuildRules()
            message = "Filter lists saved; unsupported rules: \(unsupported)"
        } catch { message = error.localizedDescription }
    }
    func newTab(privateMode: Bool = false, url: URL? = nil) {
        guard ready, tabs.count < 20 else { return }
        let tab = BrowserTab(privateMode: privateMode, ruleList: ruleList, model: self); tabs.append(tab); selected = tab.id
        if let url { tab.load(url) }
    }
    func close(_ tab: BrowserTab) { if !tab.isPrivate && !tab.url.isEmpty { closed.append(tab.url); closed = Array(closed.suffix(20)) }; tab.web.stopLoading(); tabs.removeAll { $0.id == tab.id }; if selected == tab.id { selected = tabs.last?.id }; if tabs.isEmpty { newTab() }; persist() }
    func closePrivate() { for tab in tabs.filter({ $0.isPrivate }) { close(tab) } }
    func persist() { guard ready else { return }; UserDefaults.standard.set(tabs.filter { !$0.isPrivate && !$0.url.isEmpty }.map(\.url), forKey: "session") }
    func navigate(_ text: String) { guard let url = Navigation.resolve(text, engine: UserDefaults.standard.string(forKey: "engine") ?? "DuckDuckGo") else { message = "Use an HTTP(S) link or search query"; return }; if url.scheme == "http" { pendingHTTP = url } else { current?.load(url) } }
    func clearWebData() async { await WKWebsiteDataStore.default().removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), modifiedSince: .distantPast) }
}

struct WebSurface: UIViewRepresentable {
    let web: WKWebView
    func makeUIView(context: Context) -> WKWebView { web }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
