package com.haider.browser

import com.haider.browser.adblock.FilterEngine
import com.haider.browser.data.Navigation
import org.junit.Assert.*
import org.junit.Test

class CoreTest {
    @Test
    fun domainBoundaries() {
        val e = FilterEngine()
        e.replace("||ads.example^\n@@||safe.ads.example^")
        assertTrue(e.blocked("https://cdn.ads.example/a", "https://news.test"))
        assertFalse(e.blocked("https://badads.example", "https://news.test"))
        assertFalse(e.blocked("https://safe.ads.example/a", "https://news.test"))
    }

    @Test
    fun exceptionsAndToggle() {
        val e = FilterEngine()
        e.replace("||ads.example^")
        assertFalse(
            e.blocked(
                "https://ads.example",
                "https://www.news.test",
                whitelist = setOf("news.test"),
            )
        )
        assertFalse(e.blocked("https://ads.example", "https://news.test", false))
    }

    @Test
    fun thirdParty() {
        val e = FilterEngine()
        e.replace("||example.org^\$third-party")
        assertFalse(e.blocked("https://cdn.example.org/a", "https://example.org"))
        assertTrue(e.blocked("https://example.org/a", "https://other.test"))
    }

    @Test
    fun unsupportedNotOverblocked() {
        val e = FilterEngine()
        e.replace("||example.org^\$script\n/ads/*\nnews.test##.ad\n##.adsbygoogle")
        assertEquals(3, e.unsupported)
        assertFalse(e.blocked("https://example.org/a", "https://other.test"))
        assertTrue(e.css(false).contains(".adsbygoogle"))
    }

    @Test
    fun navigationSafety() {
        assertNull(Navigation.resolve("javascript:alert(1)"))
        assertNull(Navigation.resolve("file:///etc/passwd"))
        assertNull(Navigation.resolve("data:text/html,x"))
        assertEquals("https://example.org", Navigation.resolve("example.org"))
        assertTrue(
            Navigation.resolve("hello world", "Bing")!!.startsWith("https://www.bing.com/search?q=")
        )
        assertEquals("https://example.org/a", Navigation.resolve("https://example.org/a"))
    }

    @Test
    fun malformedUrls() {
        val e = FilterEngine()
        e.replace("||ads.example^")
        assertFalse(e.blocked("not a url", "https://news.test"))
        assertNull(Navigation.resolve("https://"))
        assertNull(Navigation.resolve(""))
    }
}
