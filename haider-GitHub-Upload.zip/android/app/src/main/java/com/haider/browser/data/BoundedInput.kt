package com.haider.browser.data

import java.io.ByteArrayOutputStream
import java.io.InputStream

/** Avoid Java 9 InputStream APIs that are unavailable on older supported Android releases. */
fun InputStream.readBounded(limit: Int): ByteArray {
    val out = ByteArrayOutputStream()
    val buffer = ByteArray(8192)
    while (true) {
        val n = read(buffer)
        if (n < 0) break
        require(out.size() + n <= limit) { "File exceeds size limit" }
        out.write(buffer, 0, n)
    }
    return out.toByteArray()
}
