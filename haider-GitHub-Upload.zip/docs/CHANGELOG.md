# 0.2.0 — Premium interface refresh

- Replaced the original home layout with a smaller wordmark, original orbit/crown artwork, lighter typography and a dedicated search field.
- Added consistent vector navigation, protection, settings, search and download icons. Navigation no longer depends on font glyph rendering.
- Rebuilt protection cards around actual state and counters, and added four working website shortcuts. No invented savings or privacy metrics.
- Refined Android native dialogs, light theme and system bar colors. Kept Arabic/English and RTL/LTR support.
- Matched the visual direction in the SwiftUI iOS project with a separate PremiumStartView component. This has only passed structural/syntax checks, not an Apple SDK build.
- Fixed repeated HTTP warnings caused by processing both Enter key down and key up; added a regression step to the WebView instrumentation test.
- Cached Android orbit drawing resources when the view size changes; no animated loops or downloaded artwork.
- Prepared a manual macOS GitHub Actions workflow that can compile and package a genuine unsigned IPA after the repository is uploaded. It was not executed here. See ../IOS-IPA.md.

The advanced feature scope and platform limitations from the first release remain documented in FEATURES-AND-TESTS.md. The APK uses the same signing identity and a higher version code for upgrades.
