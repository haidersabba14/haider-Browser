# iOS startup hardening — 0.2.1

## Evidence

- Repository: haidersabba14/haider-Browser, main 3ab2fe8b87a579a9f2769c17a59ab31784367b29.
- GitHub Actions run 41469160685 completed successfully on 2026-11-02 and archived a real arm64 iOS app with Xcode 15.4 / iOS 17.5 SDK, deployment target iOS 16.
- Artifact 13153438922 contains haider-Browser.ipa; app version 0.2.0, build 2, bundle identifier com.haider.browser, native Mach-O executable. Original IPA has no Apple provisioning profile or code signature, as expected for that unsigned workflow.
- The run compiled and archived only. It did not install, launch, or UI-test the application. Neither those logs nor the user video establish the reason for the device exit. Installation/container compatibility remains unknown.

## Changes prepared

- Show a native home tab immediately. Defer WKWebView creation, content-rule compilation, and speech service initialization until their respective user actions.
- Wait for enabled content blocking before the first URL load; a failed initial rule compilation returns to home with an error instead of silently loading unprotected content.
- Restore regular-tab metadata without launching all restored websites at startup. Selecting a restored tab resumes its URL. Private tabs remain excluded from persisted sessions.
- Apply rule updates and stop closed tabs without allocating unused WebViews.
- Cover only sensitive content while the scene is inactive. The default home is no longer hidden solely because the scene has not yet become active. App/private-tab locking and vault cleanup remain enabled.
- Add an XCUITest target: three cold launches must show the home search, and a submitted localhost URL must pass the HTTP warning and render a local page.
- Run UI tests before creating an IPA and preserve xcresult/logs for a failure. No private APIs, signing workarounds, entitlements, or container bypasses are introduced.

## Verification status

Swift syntax, plist/asset JSON, Xcode references/scheme/target dependency, Bash syntax, YAML syntax and clean patch application can be checked locally on Linux. These checks do not compile against Apple SDKs.

The 0.2.1 Apple build and simulator tests have NOT been run yet. The GitHub connection currently returns HTTP 403 (Resource not accessible by integration) for writes. No claim is made that the user's physical-device crash is fixed. The pipeline is prepared to obtain executable launch evidence once repository write access is enabled.
