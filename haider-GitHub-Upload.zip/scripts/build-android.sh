#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../android"
./gradlew testDebugUnitTest lintDebug assembleRelease
: "${ANDROID_HOME:?Set ANDROID_HOME to your Android SDK directory}"
: "${HAIDER_KEYSTORE:?Set HAIDER_KEYSTORE to your private signing keystore}"
: "${HAIDER_STORE_PASSWORD:?Set HAIDER_STORE_PASSWORD for signing}"
: "${HAIDER_KEY_ALIAS:=haider}"
mkdir -p ../dist
"$ANDROID_HOME/build-tools/35.0.0/zipalign" -f -p 4 app/build/outputs/apk/release/app-release-unsigned.apk ../dist/aligned.apk
"$ANDROID_HOME/build-tools/35.0.0/apksigner" sign --ks "$HAIDER_KEYSTORE" --ks-key-alias "$HAIDER_KEY_ALIAS" --ks-pass env:HAIDER_STORE_PASSWORD --key-pass env:HAIDER_STORE_PASSWORD --out ../dist/haider-Browser.apk ../dist/aligned.apk
"$ANDROID_HOME/build-tools/35.0.0/apksigner" verify --verbose --print-certs ../dist/haider-Browser.apk
