#!/usr/bin/env python3
"""Local-only CI fixture; never required by the installed browser."""
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
class Fixture(BaseHTTPRequestHandler):
 def do_GET(self):
  data=b'<!DOCTYPE html><html><head><title>haider startup check</title><meta name="viewport" content="width=device-width"></head><body><h1>Startup fixture ready</h1><p>Native WebKit loaded this local page.</p></body></html>'
  self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
ThreadingHTTPServer(('127.0.0.1',8787),Fixture).serve_forever()
