package com.haider.browser.tabs

import android.webkit.WebView

data class Tab(
    val web: WebView,
    var title: String = "New tab",
    var url: String = "",
    var pinned: Boolean = false,
)

class TabManager {
    val items = mutableListOf<Tab>()
    val closed = ArrayDeque<String>()
    var index = 0
    val current: Tab?
        get() = items.getOrNull(index)

    fun add(tab: Tab) {
        items.add(tab)
        index = items.lastIndex
    }

    fun close(i: Int) {
        val t = items.removeAt(i)
        if (t.url.isNotEmpty()) {
            closed.addLast(t.url)
            while (closed.size > 20) closed.removeFirst()
        }
        t.web.stopLoading()
        t.web.destroy()
        index = index.coerceIn(0, (items.size - 1).coerceAtLeast(0))
    }
}
