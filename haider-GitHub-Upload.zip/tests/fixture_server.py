#!/usr/bin/env python3
"""Local integration fixture, used only during tests. Not part of app operation."""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
import base64
class Fixture(BaseHTTPRequestHandler):
 def do_GET(self):
  if self.path.startswith('/pixel'):
   data=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aFOsAAAAASUVORK5CYII='); mime='image/png'
  elif self.path=='/file.txt':data=b'haider download fixture\n';mime='application/octet-stream'
  else:
   data=b'''<!DOCTYPE html><html><head><title>Haider integration fixture</title><meta name="viewport" content="width=device-width"></head><body><h1>Browser integration test</h1><p id="content">Real WebView page loaded from a local HTTP server.</p><div class="adsbygoogle" id="ad">Cosmetic ad fixture</div><img id="pixel" src="http://127.0.0.1:8787/pixel"><a href="/file.txt">Download test file</a></body></html>''';mime='text/html'
  self.send_response(200);self.send_header('Content-Type',mime);self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
ThreadingHTTPServer(('0.0.0.0',8787),Fixture).serve_forever()
