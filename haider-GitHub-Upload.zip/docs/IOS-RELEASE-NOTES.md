# haider Browser — iOS 0.2.0

تطبيق iOS أصلي مبني من SwiftUI وWebKit على عامل macOS في GitHub Actions، يحتوي واجهة سوداء وذهبية، تبويبات وتصفحًا فعليًا، حظرًا باستخدام WKContentRuleListStore، وتخزينًا محليًا.

**ملف IPA غير موقّع بشهادة Apple.** لا يثبت مباشرة بالطريقة الرسمية قبل توقيعه وتهيئته لجهازك. تنزيل الملف ليس ضمانًا لإمكانية تثبيته على كل iPhone. لم يُختبَر توافق TrollStore أو تشغيل التطبيق على جهاز فعلي.

This is a compiled native iOS application, not a renamed source ZIP. The IPA is unsigned (`CODE_SIGNING_ALLOWED=NO`) and requires a compatible signing/install route. Target: iOS 16 or newer, iPhone/iPad. Build success does not establish real-device functionality. See FEATURES-AND-TESTS.md for the implemented, partial and unsupported feature scope.

The generated checksum accompanies the IPA. No passwords or signing secrets are published in this repository.
