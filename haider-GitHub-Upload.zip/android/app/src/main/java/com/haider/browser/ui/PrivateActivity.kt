package com.haider.browser.ui

import android.os.Bundle
import android.view.WindowManager
import android.webkit.WebView

class PrivateActivity : MainActivity() {
    override val privateMode = true

    override fun onCreate(savedInstanceState: Bundle?) {
        // Must precede every WebView API in this isolated process.
        java.io.File(applicationInfo.dataDir, "app_webview_private").deleteRecursively()
        WebView.setDataDirectorySuffix("private")
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        super.onCreate(savedInstanceState)
    }

    override fun onDestroy() {
        super.onDestroy()
        android.os.Process.killProcess(android.os.Process.myPid())
    }
}
