# إنشاء IPA حقيقي — haider Browser

**لا يوجد IPA مبني في هذا التسليم.** الكود SwiftUI وWebKit أصلي، لكن البيئة المتاحة Linux ولا يوجد اتصال بجهاز Mac. فحص الصياغة ليس بديلًا عن بناء Xcode، وقد تظهر أخطاء type-check عند أول بناء على Apple SDK.

## البناء على Mac

افتح `ios/HaiderBrowser.xcodeproj` في Xcode 16 أو أحدث متوافق، اختر scheme `haider Browser`، ثم Build. لإنشاء حزمة من التطبيق المبني فعليًا:

```bash
bash scripts/build-ios.sh --unsigned
```

الناتج عند نجاح البناء: `dist/haider-Browser-unsigned.ipa`. السكربت يتحقق من وجود ملف Mach-O حقيقي قبل التغليف. لا يحوّل HTML إلى IPA، ولا يعيد تسمية مشروع ZIP.

## البناء دون امتلاك Mac عبر GitHub Actions

أُضيف ملف `.github/workflows/ios-ipa.yml`، **ولم يُشغَّل هنا**:

1. ارفع **محتويات مجلد المشروع** إلى مستودع GitHub تملكه. يجب أن تكون `.github` و`ios` و`scripts` في جذر المستودع؛ لا ترفع ZIP وحده.
2. افتح Actions ← Build real iOS IPA (unsigned) ← Run workflow.
3. البناء يستخدم عامل macOS وXcode لدى GitHub، ولا يضيف سيرفرًا إلى تشغيل المتصفح.
4. إذا نجح البناء، نزّل artifact باسم `haider-Browser-unsigned-IPA`، وفك ZIP الخارجي للحصول على ملف IPA المبني. إذا فشل، سجّل خطأ Xcode؛ لم يُختبَر هذا المسار بعد.

تكلفة عامل GitHub تتبع سياسة GitHub وحصة حسابك؛ لا يوجد ضمان بأن جميع إعدادات الحساب مجانية. لا يبدأ هذا المشروع البناء الخارجي تلقائيًا.

## التثبيت والتوقيع

الحزمة **غير الموقّعة لا تُثبت بالطريقة الرسمية مباشرة**. التثبيت المعتاد يحتاج توقيع Apple وملف provisioning متوافقًا. على Mac، اضبط Development Team وBundle Identifier ثم شغّل من Xcode، أو استخدم سكربت التصدير الموقّع الموضح في INSTALL.md.

التوافق مع TrollStore يتوقف على الجهاز وإصدار iOS ومسار تثبيت موجود ومتوافق؛ لم يُختبَر ولا يُضمن. لا يتضمن المشروع استغلالًا أو استحقاقات خاصة أو تجاوزًا لحماية النظام.
