import SwiftUI
import WebKit
import AVFoundation
import CoreImage.CIFilterBuiltins
import UniformTypeIdentifiers

extension Color { static let haiderGold = Color(red: 212/255, green: 175/255, blue: 55/255); static let haiderBlack = Color(red: 8/255, green: 8/255, blue: 8/255) }
struct BrowserView: View {
    @StateObject private var model = BrowserModel()
    @AppStorage("language") private var language = Locale.current.language.languageCode?.identifier == "ar" ? "ar" : "en"
    @AppStorage("light") private var light = false
    @AppStorage("appLock") private var appLock = false
    @Environment(\.scenePhase) private var scenePhase
    @State private var locked = false
    @State private var address = ""
    @State private var sheet: String?
    @State private var query = ""
    @State private var note = ""
    @State private var vault = ""
    @State private var textResult = ""
    @State private var shareItems: [Any] = []
    @State private var showShare = false
    @State private var importing = false
    @State private var authInProgress = false
    @State private var homeVisible = true
    @AppStorage("block") private var protectionEnabled = true
    @State private var speaker: AVSpeechSynthesizer?
    @State private var privacyCover = false
    private var ar: Bool { language == "ar" }
    private func t(_ en: String, _ arabic: String) -> String { ar ? arabic : en }
    private var background: Color { light ? Color(red: 0.97, green: 0.96, blue: 0.93) : .haiderBlack }
    var body: some View {
        ZStack {
            background.ignoresSafeArea()
            VStack(spacing: 0) {
                if !homeVisible { HStack {
                    tool("shield.lefthalf.filled", t("Protection", "الحماية")) { sheet = "protection" }
                    TextField(t("Search or enter address", "ابحث أو أدخل رابطًا"), text: $address)
                        .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled().submitLabel(.go)
                        .onSubmit { model.navigate(address) }.padding(11).background(Color.primary.opacity(0.06), in: RoundedRectangle(cornerRadius: 14))
                    tool("arrow.clockwise", t("Reload", "إعادة تحميل")) { model.current?.web.reload() }
                }.padding(.horizontal, 9).padding(.vertical, 2).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18)).overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.primary.opacity(0.08))).padding(.horizontal, 14).padding(.vertical, 7) }
                if let tab = model.current { TabContent(tab: tab, address: $address, homeVisible: $homeVisible, ar: ar, home: { AnyView(home) }) }
                else { Spacer(); ProgressView(); Spacer() }
                HStack {
                    tool("chevron.backward", t("Back", "رجوع")) { model.current?.web.goBack() }
                    Spacer(); tool("chevron.forward", t("Forward", "تقدم")) { model.current?.web.goForward() }
                    Spacer(); tool("house", t("Home", "الرئيسية")) { model.current?.home = true }
                    Spacer(); Button { sheet = "tabs" } label: { Text("\(model.tabs.count)").font(.system(.body, design: .rounded).bold()).frame(width: 26, height: 28).overlay(RoundedRectangle(cornerRadius: 7).stroke(Color.primary.opacity(0.4))) }.accessibilityLabel(t("Tabs", "التبويبات"))
                    Spacer(); menu
                }.padding(.horizontal, 22).padding(.vertical, 9).foregroundStyle(.primary).background(.ultraThinMaterial).overlay(alignment: .top) { Rectangle().fill(Color.primary.opacity(0.07)).frame(height: 0.5) }
            }
            if locked || privacyCover {
                background.ignoresSafeArea()
                VStack(spacing: 24) { Image(systemName: "lock.shield.fill").font(.system(size: 60)).foregroundStyle(Color.haiderGold); if scenePhase == .active { Button(t("Unlock", "فتح القفل")) { unlock() }.buttonStyle(.borderedProminent) } }
            }
        }
        .tint(.haiderGold).preferredColorScheme(light ? .light : .dark)
        .environment(\.layoutDirection, ar ? .rightToLeft : .leftToRight)
        .onAppear { if appLock { locked = true; unlock() } }
        .onChange(of: model.selected) { _ in model.current?.resumeIfNeeded(); address = model.current?.url ?? ""; homeVisible = model.current?.home ?? true }
        .onChange(of: scenePhase) { phase in
            if phase != .active {
                speaker?.stopSpeaking(at: .immediate)
                privacyCover = appLock || model.current?.isPrivate == true || sheet == "vault"
                if appLock || model.current?.isPrivate == true { locked = true }
                if privacyCover { sheet = nil; vault = "" }
                model.persist()
            } else {
                privacyCover = false
                if locked { unlock() }
            }
        }
        .sheet(item: Binding(get: { sheet.map(SheetID.init) }, set: { sheet = $0?.id })) { page in NavigationStack { sheetView(page.id).navigationTitle(sheetTitle(page.id)).toolbar { ToolbarItem(placement: .confirmationAction) { Button(t("Done", "تم")) { sheet = nil; vault = "" } } } }.tint(.haiderGold).preferredColorScheme(light ? .light : .dark).environment(\.layoutDirection, ar ? .rightToLeft : .leftToRight) }
        .sheet(isPresented: $showShare) { ShareView(items: shareItems) }
        .alert(t("haider Browser", "متصفح haider"), isPresented: Binding(get: { model.message != nil }, set: { if !$0 { model.message = nil } })) { Button(t("OK", "حسنًا")) { model.message = nil } } message: { Text(model.message ?? "") }
        .alert(t("Unencrypted website", "موقع غير مشفّر"), isPresented: Binding(get: { model.pendingHTTP != nil }, set: { if !$0 { model.pendingHTTP = nil } })) {
            Button(t("Continue", "متابعة")) { if let url = model.pendingHTTP { model.approvedHTTP = url.host; model.current?.load(url) }; model.pendingHTTP = nil }
            Button(t("Cancel", "إلغاء"), role: .cancel) { model.pendingHTTP = nil }
        } message: { Text(t("Network traffic may be read or changed.", "يمكن قراءة البيانات أو تعديلها عبر الشبكة.")) }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.json]) { result in
            do { let url = try result.get(); guard url.startAccessingSecurityScopedResource() else { return }; defer { url.stopAccessingSecurityScopedResource() }; let values = try JSONDecoder().decode([SavedLink].self, from: Data(contentsOf: url)); guard values.count <= 1000, values.allSatisfy({ ["http", "https"].contains(URL(string: $0.url)?.scheme ?? "") }) else { throw URLError(.badURL) }; model.store.bookmarks = values }
            catch { model.message = error.localizedDescription }
        }
    }
    private func tool(_ icon: String, _ label: String, action: @escaping () -> Void) -> some View {
        Button(action: action) { Image(systemName: icon).font(.system(size: 19, weight: .regular)).foregroundStyle(icon == "shield.lefthalf.filled" || (icon == "house" && homeVisible) ? Color.haiderGold : Color.primary.opacity(0.8)).frame(width: 42, height: 42).background(icon == "house" && homeVisible ? Color.haiderGold.opacity(0.12) : .clear, in: RoundedRectangle(cornerRadius: 14)) }.accessibilityLabel(label)
    }
    private var home: some View {
        PremiumStartView(ar: ar, light: light, privateMode: model.current?.isPrivate == true, protectionEnabled: protectionEnabled, query: $address,
            search: { model.navigate(address) }, navigate: { model.navigate($0) },
            protection: { sheet = "protection" }, downloads: { sheet = "downloads" }, privacy: { sheet = "privacy" }, settings: { sheet = "settings" }, bookmarks: { sheet = "bookmarks" })
    }
    private var menu: some View {
        Menu {
            Button(action: { model.newTab() }) { Label(t("New tab", "تبويب جديد"), systemImage: "plus") }
            Button(action: { model.newTab(privateMode: true) }) { Label(t("New private tab", "تبويب خاص جديد"), systemImage: "eye.slash") }
            Button(action: { sheet = "bookmarks" }) { Label(t("Bookmarks", "المفضلة"), systemImage: "bookmark") }
            Button(action: { sheet = "history" }) { Label(t("History", "السجل"), systemImage: "clock") }.disabled(model.current?.isPrivate == true)
            Button(t("Bookmark page", "إضافة للمفضلة")) { if let tab = model.current, !tab.isPrivate, !tab.url.isEmpty { model.store.bookmarks.append(SavedLink(title: tab.title, url: tab.url)) } }.disabled(model.current?.isPrivate == true || model.current?.url.isEmpty != false)
            Button(action: { if let url = URL(string: model.current?.url ?? "") { shareItems = [url]; showShare = true } }) { Label(t("Share link", "مشاركة الرابط"), systemImage: "square.and.arrow.up") }
            Button(t("Find in page", "بحث داخل الصفحة")) { sheet = "find" }
            Button(t("Desktop site", "موقع سطح المكتب")) { if let web = model.current?.web { web.customUserAgent = web.customUserAgent == nil ? "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Version/17.0 Safari/605.1.15" : nil; web.reload() } }
            Button(t("Page tools", "أدوات الصفحة")) { sheet = "tools" }
            Button(action: { Task { do { guard try await LinkVault.authenticate(reason: t("Open link vault", "فتح خزنة الروابط")) else { return }; vault = try LinkVault.read(); sheet = "vault" } catch { model.message = error.localizedDescription } } }) { Label(t("Encrypted links", "الروابط المشفرة"), systemImage: "lock") }
            Button(action: { sheet = "settings" }) { Label(t("Settings", "الإعدادات"), systemImage: "gearshape") }
        } label: { Image(systemName: "line.3.horizontal").frame(width: 36, height: 40) }
    }
    private func sheetTitle(_ id: String) -> String {
        switch id { case "tabs": return t("Tabs", "التبويبات"); case "settings": return t("Settings", "الإعدادات"); case "protection": return t("Protection", "الحماية"); case "privacy": return t("Privacy", "الخصوصية"); case "downloads": return t("Downloads", "التنزيلات"); case "bookmarks": return t("Bookmarks", "المفضلة"); case "history": return t("History", "السجل"); case "tools": return t("Local tools", "أدوات محلية"); case "vault": return t("Encrypted link vault", "خزنة الروابط المشفرة"); default: return t("Page tools", "أدوات الصفحة") }
    }
    @ViewBuilder private func sheetView(_ id: String) -> some View {
        switch id {
        case "tabs":
            List {
                Button(t("New tab", "تبويب جديد")) { model.newTab(); sheet = nil }
                Button(t("New private tab", "تبويب خاص جديد")) { model.newTab(privateMode: true); sheet = nil }
                Button(t("Restore closed tab", "استعادة تبويب مغلق")) { if let url = model.closed.popLast().flatMap(URL.init(string:)) { model.newTab(url: url); sheet = nil } }
                ForEach(model.tabs) { tab in HStack { Button { model.selected = tab.id; sheet = nil } label: { Label(tab.isPrivate ? t("Private tab", "تبويب خاص") : tab.title, systemImage: tab.isPrivate ? "eye.slash" : "globe") }; Spacer(); Button(role: .destructive) { model.close(tab) } label: { Image(systemName: "xmark") } } }
            }
        case "settings": SettingsView(model: model, language: $language, light: $light, importing: $importing, export: exportBookmarks)
        case "protection": ProtectionView(model: model, ar: ar)
        case "privacy":
            List {
                Text(t("Site camera and microphone denied. TLS certificate failures are not bypassed. Private tabs use nonpersistent storage.", "تُمنع الكاميرا والميكروفون للمواقع. لا يتم تجاوز أخطاء شهادات TLS. التبويبات الخاصة تستخدم تخزينًا مؤقتًا."))
                Button(t("Clear history", "حذف السجل"), role: .destructive) { model.store.history = []; model.message = t("History deleted; close tabs to discard back/forward lists.", "حُذف السجل؛ أغلق التبويبات لمسح قوائم الرجوع والتقدم.") }
                Button(t("Clear cookies, cache & site data", "حذف الكوكيز والكاش وبيانات المواقع"), role: .destructive) { Task { await model.clearWebData() } }
                Button(t("Close all private tabs", "إغلاق التبويبات الخاصة"), role: .destructive) { model.closePrivate() }
            }
        case "bookmarks", "history", "notes": LibraryView(store: model.store, kind: id, model: model)
        case "vault": VStack { TextEditor(text: $vault).padding(); Button(t("Encrypt & save", "تشفير وحفظ")) { do { try LinkVault.save(vault); vault = ""; sheet = nil } catch { model.message = error.localizedDescription } }.padding() }
        case "find": Form { TextField(t("Find text", "ابحث عن نص"), text: $query); Button(t("Find next", "النتيجة التالية")) { model.current?.web.find(query, configuration: WKFindConfiguration()) { result in if !result.matchFound { model.message = t("No match", "لا توجد نتيجة") } } } }
        case "downloads": DownloadsView(ar: ar)
        case "note": VStack { TextEditor(text: $note).padding(); Button(t("Save note locally", "حفظ الملاحظة محليًا")) { model.store.notes.insert(SavedLink(title: String(note.prefix(60)), url: note), at: 0); note = ""; sheet = nil } }.padding()
        case "result": ScrollView { Text(textResult).textSelection(.enabled).padding() }
        case "qr": if let url = model.current?.url, let image = qr(url) { Image(uiImage: image).interpolation(.none).resizable().scaledToFit().padding(30) }
        default: tools
        }
    }
    private var tools: some View {
        List {
            Button(t("Word & character count", "عدد الكلمات والحروف")) { pageText { text in textResult = "\(text.split(whereSeparator: \.isWhitespace).count) words • \(text.count) characters"; sheet = "result" } }
            Button(t("Read aloud (system voice)", "قراءة صوتية (صوت النظام)")) { pageText { text in let speech = AVSpeechUtterance(string: String(text.prefix(10000))); speech.voice = AVSpeechSynthesisVoice(language: ar ? "ar-SA" : "en-US"); if speaker == nil { speaker = AVSpeechSynthesizer() }; speaker?.speak(speech) } }
            Button(t("Stop reading", "إيقاف القراءة")) { speaker?.stopSpeaking(at: .immediate) }
            Button(t("Copy page text", "نسخ نص الصفحة")) { pageText { UIPasteboard.general.string = $0 } }
            Button(t("Extract links", "استخراج الروابط")) { model.current?.web.evaluateJavaScript("Array.from(document.links).slice(0,300).map(a=>a.href).join('\\n')") { result, error in textResult = result as? String ?? error?.localizedDescription ?? ""; sheet = "result" } }
            Button(t("Extractive summary — no AI model", "ملخّص استخراجي — دون نموذج AI")) { pageText { text in let sentences = text.components(separatedBy: CharacterSet(charactersIn: ".!?؟\n")).filter { $0.count > 30 }; textResult = sentences.enumerated().sorted { $0.element.split(separator: " ").count > $1.element.split(separator: " ").count }.prefix(3).sorted { $0.offset < $1.offset }.map(\.element).joined(separator: ".\n"); sheet = "result" } }
            Button(t("Save page PDF", "حفظ الصفحة PDF")) { model.current?.web.createPDF(configuration: WKPDFConfiguration()) { result in do { let data = try result.get(); let path = FileManager.default.temporaryDirectory.appendingPathComponent("haider-page.pdf"); try data.write(to: path, options: .atomic); shareItems = [path]; sheet = nil; DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { showShare = true } } catch { model.message = error.localizedDescription } } }
            Button(t("Link QR code", "رمز QR للرابط")) { sheet = "qr" }
            if model.current?.isPrivate != true { Button(t("New note", "ملاحظة جديدة")) { sheet = "note" }; Button(t("Notes", "الملاحظات")) { sheet = "notes" } }
        }
    }
    private func pageText(_ done: @escaping (String) -> Void) { model.current?.web.evaluateJavaScript("document.body ? document.body.innerText.substring(0,100000) : ''") { result, _ in done(result as? String ?? "") } }
    private func qr(_ text: String) -> UIImage? { let filter = CIFilter.qrCodeGenerator(); filter.message = Data(text.utf8); guard let output = filter.outputImage, let cg = CIContext().createCGImage(output.transformed(by: .init(scaleX: 8, y: 8)), from: output.extent.applying(.init(scaleX: 8, y: 8))) else { return nil }; return UIImage(cgImage: cg) }
    private func unlock() { guard !authInProgress else { return }; authInProgress = true; Task { do { if try await LinkVault.authenticate(reason: t("Unlock haider Browser", "فتح haider Browser")) { locked = false } } catch { model.message = error.localizedDescription }; authInProgress = false } }
    private func exportBookmarks() { do { let url = FileManager.default.temporaryDirectory.appendingPathComponent("haider-bookmarks.json"); try JSONEncoder().encode(model.store.bookmarks).write(to: url, options: .atomic); shareItems = [url]; sheet = nil; DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { showShare = true } } catch { model.message = error.localizedDescription } }
}
private struct SheetID: Identifiable { let id: String; init(_ id: String) { self.id = id } }
private struct TabContent: View {
    @ObservedObject var tab: BrowserTab
    @Binding var address: String
    @Binding var homeVisible: Bool
    let ar: Bool
    let home: () -> AnyView
    var body: some View { VStack(spacing: 0) { if tab.loading { ProgressView().progressViewStyle(.linear) }; if tab.home { home() } else { WebSurface(web: tab.web).id(tab.id) } }.onChange(of: tab.url) { _ in address = tab.url; homeVisible = tab.home }.onChange(of: tab.home) { homeVisible = $0 }.onAppear { homeVisible = tab.home } }
}
struct ShareView: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: items, applicationActivities: nil) }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
