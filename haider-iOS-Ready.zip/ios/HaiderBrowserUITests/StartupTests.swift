import XCTest

final class StartupTests: XCTestCase {
    override func setUpWithError() throws { continueAfterFailure = false }
    private func configuredApp() -> XCUIApplication {
        let app = XCUIApplication()
        app.launchArguments = ["-language", "en", "-appLock", "NO", "-AppleLanguages", "(en)", "-AppleLocale", "en_US"]
        return app
    }
    func testThreeColdLaunchesShowHome() {
        let app = configuredApp()
        for attempt in 1...3 {
            app.launch()
            XCTAssertTrue(app.wait(for: .runningForeground, timeout: 20), "App exited on launch \(attempt)")
            XCTAssertTrue(app.staticTexts["haider Browser"].waitForExistence(timeout: 20), "Home hidden on launch \(attempt)")
            XCTAssertTrue(app.textFields.firstMatch.exists, "Home search missing")
            XCTAssertEqual(app.webViews.count, 0, "Home should not display a WebView")
            let image = XCTAttachment(screenshot: app.screenshot())
            image.name = "cold-launch-\(attempt)"; image.lifetime = .keepAlways
            add(image)
            app.terminate()
        }
    }
    func testProtectedNavigationLoadsLocalPage() {
        let app = configuredApp(); app.launch()
        XCTAssertTrue(app.staticTexts["haider Browser"].waitForExistence(timeout: 20))
        let input = app.textFields.firstMatch
        XCTAssertTrue(input.waitForExistence(timeout: 10))
        input.tap(); input.typeText("http://127.0.0.1:8787/\n")
        let warning = app.alerts.buttons["Continue"]
        XCTAssertTrue(warning.waitForExistence(timeout: 10)); warning.tap()
        let page = app.webViews.firstMatch
        XCTAssertTrue(page.waitForExistence(timeout: 30))
        let heading = page.descendants(matching: .any).matching(NSPredicate(format: "label == %@", "Startup fixture ready")).firstMatch
        XCTAssertTrue(heading.waitForExistence(timeout: 30), "First navigation failed to finish")
        XCTAssertEqual(app.state, .runningForeground)
        let image = XCTAttachment(screenshot: app.screenshot())
        image.name = "protected-local-navigation"; image.lifetime = .keepAlways; add(image)
        app.terminate()
    }
}
