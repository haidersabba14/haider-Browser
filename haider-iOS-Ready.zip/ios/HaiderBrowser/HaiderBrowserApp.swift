import SwiftUI
@main struct HaiderBrowserApp: App {
    var body: some Scene { WindowGroup { BrowserView() } }
}
