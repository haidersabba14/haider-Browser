#!/usr/bin/env python3
from pathlib import Path
import plistlib,json
from tree_sitter import Language,Parser
import tree_sitter_swift
from pbxproj import XcodeProject
root=Path(__file__).resolve().parents[1]/'ios'
parser=Parser(Language(tree_sitter_swift.language()))
for file in root.rglob('*.swift'):
 tree=parser.parse(file.read_bytes())
 assert not tree.root_node.has_error, f'Swift syntax error in {file}: {tree.root_node}'
for file in list(root.rglob('*.plist'))+list(root.rglob('*.xcprivacy')):
 plistlib.loads(file.read_bytes())
for file in root.rglob('*.json'):json.loads(file.read_text())
project=XcodeProject.load(str(root/'HaiderBrowser.xcodeproj/project.pbxproj'))
assert project is not None
for file in project.objects.get_objects_in_section('PBXFileReference'):
 if str(file.sourceTree)=='<group>':assert (root/str(file.path)).exists(), file.path
print('PASS: Swift syntax, plists, assets JSON and Xcode project references. NOT an iOS build or type-check.')
