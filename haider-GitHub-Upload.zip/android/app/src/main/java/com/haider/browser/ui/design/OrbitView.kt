package com.haider.browser.ui.design

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.widget.ImageView

/** Original vector artwork. Cache drawing resources when size changes, never per frame. */
class OrbitView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) :
    ImageView(context, attrs) {
    init {
        scaleType = ScaleType.FIT_XY
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    private var light = false

    constructor(context: Context, light: Boolean) : this(context) {
        this.light = light
    }

    private val density = resources.displayMetrics.density
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val disk = Paint(Paint.ANTI_ALIAS_FLAG)
    private val orbit =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = density * 0.65f
        }
    private val star = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(212, 175, 55) }
    private val mark = BrowserIcon("crown", Color.rgb(225, 199, 113), (density * 28).toInt())

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w <= 0 || h <= 0) return
        val cx = w / 2f
        val cy = h / 2f
        glow.shader =
            RadialGradient(
                cx,
                cy,
                h * .65f,
                intArrayOf(Color.argb(35, 212, 175, 55), Color.TRANSPARENT),
                null,
                Shader.TileMode.CLAMP,
            )
        disk.shader =
            LinearGradient(
                cx - h * .23f,
                cy - h * .23f,
                cx + h * .23f,
                cy + h * .23f,
                intArrayOf(Color.rgb(53, 47, 31), Color.rgb(13, 13, 13)),
                null,
                Shader.TileMode.CLAMP,
            )
        val s = h * .28f
        mark.setBounds(
            (cx - s / 2).toInt(),
            (cy - s / 2).toInt(),
            (cx + s / 2).toInt(),
            (cy + s / 2).toInt(),
        )
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bitmap.density = resources.displayMetrics.densityDpi
        drawArtwork(Canvas(bitmap))
        setImageBitmap(bitmap)
    }

    private fun drawArtwork(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2
        val cy = h / 2
        canvas.drawRect(0f, 0f, w, h, glow)
        orbit.color = Color.argb(if (light) 60 else 50, 212, 175, 55)
        canvas.save()
        canvas.rotate(-18f, cx, cy)
        canvas.drawOval(cx - h * .88f, cy - h * .25f, cx + h * .88f, cy + h * .25f, orbit)
        canvas.restore()
        orbit.color = Color.argb(28, 212, 175, 55)
        canvas.drawCircle(cx, cy, h * .43f, orbit)
        canvas.save()
        canvas.rotate(23f, cx, cy)
        canvas.drawOval(cx - h * .68f, cy - h * .39f, cx + h * .68f, cy + h * .39f, orbit)
        canvas.restore()
        canvas.drawCircle(cx, cy, h * .26f, disk)
        orbit.color = Color.argb(150, 212, 175, 55)
        canvas.drawCircle(cx, cy, h * .26f, orbit)
        mark.draw(canvas)
        star.alpha = 255
        canvas.drawCircle(cx + h * .69f, cy - h * .19f, density * 2f, star)
        star.alpha = 150
        canvas.drawCircle(cx - h * .49f, cy + h * .31f, density * 1.5f, star)
    }
}
