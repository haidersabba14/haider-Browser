#!/usr/bin/env python3
from pathlib import Path
import json
from PIL import Image,ImageDraw
root=Path(__file__).resolve().parents[1]
assets=root/'ios/HaiderBrowser/Assets.xcassets'
assets.mkdir(parents=True,exist_ok=True)
(assets/'Contents.json').write_text(json.dumps({'info':{'author':'xcode','version':1}}))
im=Image.new('RGB',(1024,1024),'#080808');d=ImageDraw.Draw(im);g='#D4AF37'
d.ellipse((140,140,884,884),outline=g,width=10)
d.polygon([(270,340),(385,435),(512,245),(639,435),(754,340),(703,620),(321,620)],fill=g)
d.rounded_rectangle((321,658,703,704),radius=12,fill=g)
d.rectangle((400,751,445,850),fill=g);d.rectangle((579,751,624,850),fill=g);d.rectangle((440,786,584,818),fill=g)
icon=assets/'AppIcon.appiconset';icon.mkdir(exist_ok=True)
im.save(icon/'AppIcon.png')
(icon/'Contents.json').write_text(json.dumps({'images':[{'filename':'AppIcon.png','idiom':'universal','platform':'ios','size':'1024x1024'}],'info':{'author':'xcode','version':1}},indent=2))
launch=assets/'LaunchLogo.imageset';launch.mkdir(exist_ok=True);im.resize((160,160)).save(launch/'LaunchLogo.png');(launch/'Contents.json').write_text(json.dumps({'images':[{'filename':'LaunchLogo.png','idiom':'universal'}],'info':{'author':'xcode','version':1}}))
color=assets/'LaunchBackground.colorset';color.mkdir(exist_ok=True);(color/'Contents.json').write_text(json.dumps({'colors':[{'idiom':'universal','color':{'color-space':'srgb','components':{'red':'0.031','green':'0.031','blue':'0.031','alpha':'1.000'}}}],'info':{'author':'xcode','version':1}}))
(root/'docs/logo.png').write_bytes((icon/'AppIcon.png').read_bytes())
