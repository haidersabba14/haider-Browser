package com.haider.browser.ui

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.biometrics.BiometricPrompt
import android.net.Uri
import android.os.*
import android.print.PrintManager
import android.speech.tts.TextToSpeech
import android.view.*
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.haider.browser.adblock.FilterEngine
import com.haider.browser.data.*
import com.haider.browser.downloads.DownloadController
import com.haider.browser.privacy.LinkVault
import com.haider.browser.tabs.*
import com.haider.browser.ui.design.BrowserIcon
import com.haider.browser.ui.design.OrbitView
import java.io.ByteArrayInputStream
import java.net.URL
import java.time.LocalDate
import java.util.Locale
import org.json.*

open class MainActivity : Activity() {
    open val privateMode = false
    private lateinit var store: LocalStore
    private val tabs = TabManager()
    private val filter = FilterEngine()
    private lateinit var downloads: DownloadController
    private lateinit var root: LinearLayout
    private lateinit var top: LinearLayout
    private lateinit var content: FrameLayout
    private lateinit var address: EditText
    private lateinit var count: Button
    private lateinit var shield: Button
    private lateinit var progress: ProgressBar
    private lateinit var homeControl: Button
    private var arabic = false
    private var light = false
    private var locked = false
    private var authBusy = false
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var resumedOnce = false
    private var fullscreen: View? = null
    private var fullscreenCallback: WebChromeClient.CustomViewCallback? = null
    private var sensitiveDialog: AlertDialog? = null
    private var pageError = false
    private var httpDialog: AlertDialog? = null
    private var upload: ValueCallback<Array<Uri>>? = null
    private val gold = Color.rgb(212, 175, 55)
    private val bg
        get() = if (light) Color.rgb(248, 246, 239) else Color.rgb(8, 8, 8)

    private val fg
        get() = if (light) Color.rgb(20, 20, 20) else Color.WHITE

    private val panel
        get() = if (light) Color.WHITE else Color.rgb(21, 22, 24)

    private fun tr(en: String, ar: String) = if (arabic) ar else en

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun shape(color: Int = panel) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(16).toFloat()
            setStroke(dp(1), if (light) Color.rgb(225, 224, 218) else Color.rgb(44, 44, 43))
        }

    private fun label(s: String, size: Float = 16f) =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(fg)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }

    private fun button(text: String, action: () -> Unit) =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 14f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            stateListAnimator = null
            setTextColor(fg)
            background = shape()
            minWidth = 0
            minimumWidth = 0
            setPadding(dp(8), 0, dp(8), 0)
            setOnClickListener { action() }
        }

    private fun icon(name: String, color: Int = fg, size: Int = 22) =
        BrowserIcon(name, color, dp(size)).apply { setBounds(0, 0, dp(size), dp(size)) }

    private fun iconButton(name: String, title: String, color: Int = fg, action: () -> Unit) =
        button("", action).apply {
            contentDescription = title
            background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            setCompoundDrawables(icon(name, color), null, null, null)
        }

    private fun text(s: String, size: Float, color: Int = fg, weight: String = "sans-serif") =
        label(s, size).apply {
            setPadding(0, 0, 0, 0)
            setTextColor(color)
            typeface = Typeface.create(weight, Typeface.NORMAL)
            includeFontPadding = false
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun gap(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun sectionTitle(title: String, actionTitle: String, action: () -> Unit): LinearLayout =
        row().apply {
            addView(
                text(title, 14f, fg, "sans-serif-medium"),
                LinearLayout.LayoutParams(0, dp(30), 1f).apply { gravity = Gravity.CENTER_VERTICAL },
            )
            addView(
                button(actionTitle, action).apply {
                    background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
                    textSize = 12f
                    setTextColor(gold)
                },
                LinearLayout.LayoutParams(-2, dp(34)),
            )
        }

    private fun col() =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundColor(bg)
        }

    private fun row() =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun field(hint: String, value: String = "") =
        EditText(this).apply {
            this.hint = hint
            setText(value)
            setTextColor(fg)
            setHintTextColor(Color.GRAY)
            maxLines = 5
        }

    private fun dialog(title: String, view: View) =
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(view)
            .setNegativeButton(tr("Close", "إغلاق"), null)
            .show()
            .apply { setOnDismissListener { if (tabs.current?.url?.isEmpty() == true) attach() } }

    private fun ask(title: String, value: String = "", action: (String) -> Unit) {
        val f = field(title, value)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(f)
            .setPositiveButton(tr("Save", "حفظ")) { _, _ ->
                runCatching { action(f.text.toString()) }.onFailure { toast(it.message ?: "Error") }
            }
            .setNegativeButton(tr("Cancel", "إلغاء"), null)
            .show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = LocalStore(this)
        downloads = DownloadController(this)
        arabic = store.prefs.getString("language", Locale.getDefault().language) == "ar"
        light = store.prefs.getBoolean("light", false)
        filter.replace(
            FilterEngine.seed +
                "\n" +
                (if (store.filters.exists()) store.filters.readText() else "") +
                "\n" +
                store.prefs.getString("rules", "")
        )
        if (privateMode) {
            CookieManager.getInstance().removeAllCookies(null)
            WebStorage.getInstance().deleteAllData()
        }
        if (store.prefs.getBoolean("lock", false))
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        buildUI()
        if (!privateMode) {
            val session = store.list("session")
            for (i in 0 until session.length().coerceAtMost(20)) newTab(session.optString(i), false)
        }
        if (tabs.items.isEmpty()) newTab("", false)
        attach()
        intent?.dataString?.let { navigate(it) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.dataString?.let { newTab(it) }
    }

    private fun buildUI() {
        setTheme(
            if (light) com.haider.browser.R.style.AppThemeLight
            else com.haider.browser.R.style.AppTheme
        )
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility =
            if (light)
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            else 0
        root =
            LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(bg)
                layoutDirection =
                    if (arabic) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
            }
        root.setOnApplyWindowInsetsListener { v, i ->
            v.setPadding(
                i.systemWindowInsetLeft,
                i.systemWindowInsetTop,
                i.systemWindowInsetRight,
                i.systemWindowInsetBottom,
            )
            i
        }
        top =
            row().apply {
                setPadding(dp(12), dp(6), dp(12), dp(6))
                background = shape()
            }
        shield = iconButton("shield", tr("Protection", "الحماية"), gold) { protection() }
        shield.contentDescription = tr("Protection", "الحماية")
        address =
            field(tr("Search or enter address", "ابحث أو أدخل رابطًا")).apply {
                isSingleLine = true
                background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
                textSize = 14f
                inputType =
                    android.text.InputType.TYPE_CLASS_TEXT or
                        android.text.InputType.TYPE_TEXT_VARIATION_URI
                imeOptions = EditorInfo.IME_ACTION_GO
                setSelectAllOnFocus(true)
                setOnEditorActionListener { _, a, event ->
                    if (
                        (event == null && a == EditorInfo.IME_ACTION_GO) ||
                            (event?.keyCode == KeyEvent.KEYCODE_ENTER &&
                                event.action == KeyEvent.ACTION_DOWN)
                    ) {
                        navigate(text.toString())
                        clearFocus()
                        (getSystemService(INPUT_METHOD_SERVICE)
                                as android.view.inputmethod.InputMethodManager)
                            .hideSoftInputFromWindow(windowToken, 0)
                        true
                    } else false
                }
            }
        top.addView(shield, LinearLayout.LayoutParams(dp(44), dp(46)))
        top.addView(address, LinearLayout.LayoutParams(0, dp(50), 1f))
        top.addView(
            iconButton("reload", tr("Reload", "إعادة تحميل")) { tabs.current?.web?.reload() },
            LinearLayout.LayoutParams(dp(44), dp(46)),
        )
        root.addView(
            top,
            LinearLayout.LayoutParams(-1, dp(54)).apply { setMargins(dp(14), dp(6), dp(14), dp(6)) },
        )
        progress =
            ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                progressTintList = android.content.res.ColorStateList.valueOf(gold)
                max = 100
            }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(2)))
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav =
            row().apply {
                setPadding(dp(18), dp(6), dp(18), dp(6))
                setBackgroundColor(bg)
            }
        fun addNav(control: Button) {
            val holder = FrameLayout(this)
            holder.addView(control, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER))
            nav.addView(holder, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        addNav(
            iconButton("back", tr("Back", "رجوع")) {
                tabs.current?.web?.let { if (it.canGoBack()) it.goBack() }
            }
        )
        addNav(
            iconButton("forward", tr("Forward", "تقدم")) {
                tabs.current?.web?.let { if (it.canGoForward()) it.goForward() }
            }
        )
        homeControl =
            iconButton("home", tr("Home", "الرئيسية"), gold) {
                tabs.current?.url = ""
                attach()
            }
        addNav(homeControl)
        count =
            button("1") { tabSheet() }
                .apply {
                    contentDescription = tr("Tabs", "التبويبات")
                    background = shape(Color.TRANSPARENT)
                    textSize = 13f
                }
        val holder = FrameLayout(this)
        holder.addView(count, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER))
        nav.addView(holder, LinearLayout.LayoutParams(0, dp(48), 1f))
        addNav(iconButton("menu", tr("Menu", "القائمة")) { menu() })
        root.addView(
            View(this).apply {
                setBackgroundColor(if (light) Color.rgb(226, 225, 219) else Color.rgb(30, 30, 30))
            },
            LinearLayout.LayoutParams(-1, dp(1)),
        )
        root.addView(nav)
        setContentView(root)
    }

    @Suppress("SetJavaScriptEnabled")
    private fun newTab(url: String = "", attachNow: Boolean = true) {
        if (tabs.items.size >= 20) {
            toast(tr("Limit: 20 active tabs", "الحد: 20 تبويبًا نشطًا"))
            return
        }
        val web = WebView(this)
        web.setBackgroundColor(Color.WHITE)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            mediaPlaybackRequiresUserGesture = true
            safeBrowsingEnabled = true
            saveFormData = false
            setGeolocationEnabled(false)
            builtInZoomControls = true
            displayZoomControls = false
            loadsImagesAutomatically = !store.prefs.getBoolean("noImages", false)
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)
        val tab = Tab(web)
        tabs.add(tab)
        web.webViewClient =
            object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest,
                ): Boolean {
                    val u = request.url.toString()
                    if (request.url.scheme !in listOf("http", "https")) {
                        if (request.isForMainFrame)
                            toast(tr("Unsupported link type", "نوع الرابط غير مدعوم"))
                        return true
                    }
                    if (
                        request.isForMainFrame &&
                            request.url.scheme == "http" &&
                            !tab.url.startsWith("http://")
                    ) {
                        runOnUiThread { confirmHttp(u) }
                        return true
                    }
                    return false
                }

                override fun shouldInterceptRequest(
                    view: WebView,
                    request: WebResourceRequest,
                ): WebResourceResponse? {
                    if (request.isForMainFrame) return null
                    val white = store.prefs.getStringSet("white", emptySet()) ?: emptySet()
                    if (
                        filter.blocked(
                            request.url.toString(),
                            tab.url,
                            store.prefs.getBoolean("block", true),
                            white,
                        )
                    ) {
                        if (!privateMode)
                            synchronized(store) {
                                val day = LocalDate.now().toString()
                                val k = "blocked.$day"
                                store.prefs.edit().putLong(k, store.prefs.getLong(k, 0) + 1).apply()
                            }
                        runOnUiThread {
                            if (tabs.current === tab)
                                shield.contentDescription =
                                    tr("Protection — request blocked", "الحماية — تم حظر طلب")
                        }
                        return WebResourceResponse(
                            "text/plain",
                            "UTF-8",
                            204,
                            "Blocked",
                            mapOf("Cache-Control" to "no-store"),
                            ByteArrayInputStream(byteArrayOf()),
                        )
                    }
                    return null
                }

                override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                    tab.url = url
                    pageError = false
                    if (tabs.current === tab) {
                        address.setText(url)
                        progress.visibility = View.VISIBLE
                    }
                    saveSession()
                }

                override fun onPageFinished(view: WebView, url: String) {
                    tab.title = view.title ?: url
                    tab.url = url
                    if (!privateMode && !pageError) store.add("history", tab.title, url)
                    if (tabs.current === tab) {
                        address.setText(url)
                        progress.visibility = View.GONE
                    }
                    if (
                        store.prefs.getBoolean("block", true) &&
                            !(store.prefs.getStringSet("white", emptySet()) ?: emptySet()).any {
                                FilterEngine.matches(FilterEngine.host(url) ?: "", it)
                            }
                    ) {
                        val css = filter.css(store.prefs.getBoolean("strong", false))
                        view.evaluateJavascript(
                            "(function(){let s=document.getElementById('haider-adblock');if(!s){s=document.createElement('style');s.id='haider-adblock';document.documentElement.appendChild(s)}s.textContent=" +
                                JSONObject.quote(css) +
                                "})()",
                            null,
                        )
                    }
                    saveSession()
                }

                override fun onReceivedError(
                    view: WebView,
                    request: WebResourceRequest,
                    error: WebResourceError,
                ) {
                    if (request.isForMainFrame) {
                        pageError = true
                        runOnUiThread { toast(error.description.toString()) }
                    }
                }

                override fun onReceivedSslError(
                    view: WebView,
                    handler: android.webkit.SslErrorHandler,
                    error: android.net.http.SslError,
                ) {
                    handler.cancel()
                    runOnUiThread { toast(tr("TLS certificate rejected", "تم رفض شهادة الأمان")) }
                }
            }
        web.webChromeClient =
            object : WebChromeClient() {
                override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                    if (fullscreen != null) {
                        callback.onCustomViewHidden()
                        return
                    }
                    fullscreen = view
                    fullscreenCallback = callback
                    root.visibility = View.GONE
                    addContentView(view, android.view.ViewGroup.LayoutParams(-1, -1))
                    window.decorView.systemUiVisibility =
                        View.SYSTEM_UI_FLAG_FULLSCREEN or
                            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                }

                override fun onHideCustomView() {
                    exitFullscreen()
                }

                override fun onProgressChanged(view: WebView, p: Int) {
                    if (tabs.current === tab) progress.progress = p
                }

                override fun onPermissionRequest(request: PermissionRequest) {
                    request.deny()
                    runOnUiThread {
                        toast(
                            tr(
                                "Camera and microphone access denied by privacy policy",
                                "تم منع الكاميرا والميكروفون لحماية الخصوصية",
                            )
                        )
                    }
                }

                override fun onCreateWindow(
                    view: WebView,
                    isDialog: Boolean,
                    isUserGesture: Boolean,
                    resultMsg: Message,
                ): Boolean {
                    return false
                }

                override fun onShowFileChooser(
                    web: WebView,
                    callback: ValueCallback<Array<Uri>>,
                    params: FileChooserParams,
                ): Boolean {
                    if (privateMode) return false
                    upload?.onReceiveValue(null)
                    upload = callback
                    startActivityForResult(
                        Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            type = "*/*"
                            addCategory(Intent.CATEGORY_OPENABLE)
                        },
                        104,
                    )
                    return true
                }
            }
        web.setDownloadListener { u, a, d, m, _ ->
            if (privateMode)
                toast(tr("Downloads disabled in private mode", "التنزيل معطّل في الوضع الخاص"))
            else
                AlertDialog.Builder(this)
                    .setTitle(tr("Download file?", "تنزيل الملف؟"))
                    .setMessage(Uri.parse(u).host)
                    .setPositiveButton(tr("Download", "تنزيل")) { _, _ ->
                        runCatching {
                                val id = downloads.enqueue(u, a, d, m, false)
                                val ids =
                                    store.prefs
                                        .getStringSet("downloadIds", emptySet())!!
                                        .toMutableSet()
                                ids.add(id.toString())
                                store.prefs.edit().putStringSet("downloadIds", ids).apply()
                                toast(tr("Download started", "بدأ التنزيل"))
                            }
                            .onFailure { toast(it.message ?: "Error") }
                    }
                    .setNegativeButton(tr("Cancel", "إلغاء"), null)
                    .show()
        }
        if (url.isNotBlank())
            Navigation.resolve(url, store.prefs.getString("engine", "DuckDuckGo")!!)?.let {
                tab.url = it
                web.loadUrl(it)
            }
        if (attachNow) attach()
    }

    private fun exitFullscreen() {
        fullscreen?.let { (it.parent as? android.view.ViewGroup)?.removeView(it) }
        fullscreen = null
        fullscreenCallback?.onCustomViewHidden()
        fullscreenCallback = null
        root.visibility = View.VISIBLE
        window.decorView.systemUiVisibility =
            if (light)
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            else 0
    }

    private fun attach() {
        content.removeAllViews()
        val t = tabs.current ?: return
        count.text = tabs.items.size.toString()
        address.setText(t.url)
        progress.visibility = View.GONE
        top.visibility = if (t.url.isEmpty()) View.GONE else View.VISIBLE
        homeControl.background =
            if (t.url.isEmpty())
                shape(if (light) Color.rgb(235, 229, 208) else Color.rgb(35, 32, 21))
            else android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
        if (t.url.isEmpty()) home()
        else {
            (t.web.parent as? android.view.ViewGroup)?.removeView(t.web)
            content.addView(t.web, FrameLayout.LayoutParams(-1, -1))
        }
        saveSession()
    }

    private fun home() {
        val muted = if (light) Color.rgb(116, 116, 111) else Color.rgb(148, 148, 148)
        val scroll =
            ScrollView(this).apply {
                isVerticalScrollBarEnabled = false
                clipToPadding = false
            }
        val c = col().apply { setPadding(dp(24), dp(12), dp(24), dp(24)) }
        scroll.addView(c)
        content.addView(scroll)
        val header = row()
        val logo =
            ImageView(this).apply {
                setImageDrawable(icon("crown", gold, 21))
                background = shape(if (light) Color.rgb(237, 231, 210) else Color.rgb(32, 29, 20))
                setPadding(dp(9), dp(9), dp(9), dp(9))
            }
        header.addView(logo, LinearLayout.LayoutParams(dp(38), dp(38)))
        header.addView(
            text("haider Browser", 17f, fg, "sans-serif-medium").apply {
                setPadding(dp(11), 0, 0, 0)
            },
            LinearLayout.LayoutParams(0, dp(40), 1f),
        )
        header.addView(
            iconButton(
                if (privateMode) "private" else "settings",
                tr("Settings", "الإعدادات"),
                muted,
            ) {
                settings()
            },
            LinearLayout.LayoutParams(dp(40), dp(40)),
        )
        c.addView(header)
        gap(c, 14)
        c.addView(OrbitView(this, light), LinearLayout.LayoutParams(-1, dp(104)))
        gap(c, 8)
        c.addView(
            text(
                    if (privateMode) tr("PRIVATE BROWSING", "تصفح خاص")
                    else tr("A LITTLE MORE FREEDOM", "مساحة أوسع لحريتك"),
                    10f,
                    gold,
                    "sans-serif-medium",
                )
                .apply {
                    letterSpacing = if (arabic) 0f else .19f
                    gravity = Gravity.CENTER
                },
            LinearLayout.LayoutParams(-1, -2),
        )
        gap(c, 12)
        c.addView(
            text(
                    if (privateMode) tr("A moment.\nJust for you.", "لحظتك.\nبخصوصية أكبر.")
                    else tr("Explore more.\nLeave less behind.", "اكتشف أكثر.\nاترك أثرًا أقل."),
                    34f,
                    fg,
                    "sans-serif-light",
                )
                .apply {
                    gravity = Gravity.CENTER
                    setLineSpacing(dp(2).toFloat(), 1f)
                },
            LinearLayout.LayoutParams(-1, -2),
        )
        gap(c, 12)
        c.addView(
            text(tr("Your next discovery starts here.", "كل اكتشاف جديد يبدأ من هنا."), 13f, muted)
                .apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(-1, -2),
        )
        gap(c, 26)
        val search =
            row().apply {
                background = shape(if (light) Color.WHITE else Color.rgb(24, 25, 27))
                setPadding(dp(16), dp(4), dp(7), dp(4))
            }
        search.addView(
            ImageView(this).apply { setImageDrawable(icon("search", muted, 20)) },
            LinearLayout.LayoutParams(dp(22), dp(32)),
        )
        val homeSearch =
            field(tr("Search or enter a URL", "ابحث أو أدخل رابطًا")).apply {
                isSingleLine = true
                textSize = 14f
                setPadding(dp(12), 0, dp(4), 0)
                background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
                inputType =
                    android.text.InputType.TYPE_CLASS_TEXT or
                        android.text.InputType.TYPE_TEXT_VARIATION_URI
                imeOptions = EditorInfo.IME_ACTION_GO
                setOnEditorActionListener { _, a, event ->
                    if (
                        (event == null && a == EditorInfo.IME_ACTION_GO) ||
                            (event?.keyCode == KeyEvent.KEYCODE_ENTER &&
                                event.action == KeyEvent.ACTION_DOWN)
                    ) {
                        navigate(text.toString())
                        (getSystemService(INPUT_METHOD_SERVICE)
                                as android.view.inputmethod.InputMethodManager)
                            .hideSoftInputFromWindow(windowToken, 0)
                        true
                    } else false
                }
            }
        search.addView(homeSearch, LinearLayout.LayoutParams(0, dp(52), 1f))
        search.addView(
            iconButton("arrow", tr("Search", "بحث"), Color.rgb(20, 20, 17)) {
                    navigate(homeSearch.text.toString())
                }
                .apply { background = shape(gold) },
            LinearLayout.LayoutParams(dp(42), dp(42)),
        )
        c.addView(search, LinearLayout.LayoutParams(-1, dp(62)))
        gap(c, 25)
        val protectionCard =
            LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(18), dp(16), dp(18), dp(16))
                background =
                    GradientDrawable(
                            GradientDrawable.Orientation.TL_BR,
                            intArrayOf(
                                if (light) Color.rgb(241, 236, 219) else Color.rgb(36, 33, 24),
                                if (light) Color.WHITE else Color.rgb(20, 21, 22),
                            ),
                        )
                        .apply {
                            cornerRadius = dp(20).toFloat()
                            setStroke(
                                dp(1),
                                if (light) Color.rgb(222, 213, 184) else Color.rgb(65, 57, 34),
                            )
                        }
                setOnClickListener { protection() }
                isFocusable = true
                contentDescription = tr("AdBlock settings", "إعدادات مانع الإعلانات")
            }
        val cardHeader = row()
        cardHeader.addView(
            ImageView(this).apply { setImageDrawable(icon("shield", gold, 19)) },
            LinearLayout.LayoutParams(dp(22), dp(24)),
        )
        cardHeader.addView(
            text("haider AdBlock PRO", 13f, fg, "sans-serif-medium").apply {
                setPadding(dp(8), 0, 0, 0)
            },
            LinearLayout.LayoutParams(0, dp(24), 1f),
        )
        val enabled = store.prefs.getBoolean("block", true)
        cardHeader.addView(
            text(
                    if (enabled) tr("ON", "مفعّل") else tr("OFF", "متوقف"),
                    9f,
                    if (enabled) gold else muted,
                    "sans-serif-medium",
                )
                .apply {
                    letterSpacing = if (arabic) 0f else .12f
                    gravity = Gravity.CENTER
                    background =
                        shape(if (light) Color.rgb(231, 223, 195) else Color.rgb(54, 47, 28))
                },
            LinearLayout.LayoutParams(dp(46), dp(23)),
        )
        protectionCard.addView(cardHeader)
        gap(protectionCard, 14)
        if (privateMode)
            protectionCard.addView(
                text(
                    tr(
                        "Private activity stays out of your history.",
                        "لا يُحفظ النشاط الخاص في سجلك.",
                    ),
                    13f,
                    muted,
                )
            )
        else {
            val stat = row()
            val n = store.prefs.getLong("blocked.${LocalDate.now()}", 0)
            stat.addView(
                text(
                    java.text.NumberFormat.getIntegerInstance(
                            if (arabic) Locale.forLanguageTag("ar") else Locale.ENGLISH
                        )
                        .format(n),
                    30f,
                    fg,
                    "sans-serif-light",
                ),
                LinearLayout.LayoutParams(-2, dp(38)),
            )
            stat.addView(
                text(tr("requests blocked today", "طلب محظور اليوم"), 12f, muted).apply {
                    setPadding(dp(12), dp(10), 0, 0)
                },
                LinearLayout.LayoutParams(0, dp(38), 1f),
            )
            protectionCard.addView(stat)
        }
        c.addView(protectionCard, LinearLayout.LayoutParams(-1, -2))
        gap(c, 24)
        c.addView(
            sectionTitle(tr("Your shortcuts", "اختصاراتك"), tr("Bookmarks", "المفضلة")) {
                library("bookmarks")
            }
        )
        gap(c, 10)
        val quick = row()
        val shortcuts =
            listOf(
                Triple("W", "Wikipedia", "https://wikipedia.org"),
                Triple("D", "DuckDuckGo", "https://duckduckgo.com"),
                Triple("G", "Google", "https://google.com"),
                Triple("▶", "YouTube", "https://youtube.com"),
            )
        shortcuts.forEachIndexed { i, (mark, title, url) ->
            val tile =
                LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setOnClickListener { navigate(url) }
                    contentDescription = title
                    isClickable = true
                    isFocusable = true
                }
            val tint =
                when (i) {
                    1 -> Color.rgb(224, 139, 90)
                    2 -> Color.rgb(119, 165, 239)
                    3 -> Color.rgb(229, 112, 106)
                    else -> fg
                }
            tile.addView(
                button(mark) { navigate(url) }
                    .apply {
                        textSize = 22f
                        setTextColor(tint)
                        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                    },
                LinearLayout.LayoutParams(dp(51), dp(51)),
            )
            tile.addView(
                text(title, 10f, muted).apply {
                    gravity = Gravity.CENTER
                    setPadding(0, dp(9), 0, 0)
                },
                LinearLayout.LayoutParams(-1, dp(28)),
            )
            quick.addView(tile, LinearLayout.LayoutParams(0, dp(82), 1f))
        }
        c.addView(quick)
        gap(c, 23)

        gap(c, 20)
        val utilities = row()
        listOf(
                Triple("download", tr("Downloads", "التنزيلات"), { downloadSheet() }),
                Triple("private", tr("Privacy", "الخصوصية"), { privacy() }),
                Triple("settings", tr("Settings", "الإعدادات"), { settings() }),
            )
            .forEach { (glyph, title, action) ->
                val item =
                    LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        gravity = Gravity.CENTER
                        setOnClickListener { action() }
                        isFocusable = true
                        contentDescription = title
                    }
                item.addView(
                    iconButton(glyph, title, muted, action),
                    LinearLayout.LayoutParams(dp(42), dp(34)),
                )
                item.addView(
                    text(title, 11f, muted).apply { gravity = Gravity.CENTER },
                    LinearLayout.LayoutParams(-1, dp(24)),
                )
                utilities.addView(item, LinearLayout.LayoutParams(0, dp(66), 1f))
            }
        c.addView(utilities)
        gap(c, 10)
        c.addView(
            text(
                    tr(
                        "NO ACCOUNT. NO APP ADS. JUST YOUR WEB.",
                        "بلا حساب. بلا إعلانات داخل التطبيق.",
                    ),
                    8f,
                    muted,
                )
                .apply {
                    gravity = Gravity.CENTER
                    letterSpacing = if (arabic) 0f else .12f
                },
            LinearLayout.LayoutParams(-1, -2),
        )
    }

    private fun navigate(input: String) {
        val u =
            Navigation.resolve(input, store.prefs.getString("engine", "DuckDuckGo")!!)
                ?: run {
                    toast(
                        tr(
                            "Enter a valid HTTP(S) address or search",
                            "أدخل رابط HTTP(S) صالحًا أو عبارة بحث",
                        )
                    )
                    return
                }
        if (u.startsWith("http://")) {
            confirmHttp(u)
            return
        }
        load(u)
    }

    private fun load(u: String) {
        val t = tabs.current ?: return
        t.url = u
        attach()
        t.web.loadUrl(u)
    }

    private fun confirmHttp(u: String) {
        if (httpDialog?.isShowing == true) return
        httpDialog =
            AlertDialog.Builder(this)
                .setTitle(tr("Unencrypted website", "موقع غير مشفّر"))
                .setMessage(
                    tr(
                        "Traffic may be read or modified on the network. Continue?",
                        "قد تتم قراءة البيانات أو تعديلها عبر الشبكة. هل تريد المتابعة؟",
                    )
                )
                .setPositiveButton(tr("Continue", "متابعة")) { _, _ -> load(u) }
                .setNegativeButton(tr("Cancel", "إلغاء"), null)
                .setOnDismissListener { httpDialog = null }
                .show()
    }

    private fun saveSession() {
        if (!privateMode) {
            val a = JSONArray()
            tabs.items.filter { it.url.startsWith("http") }.forEach { a.put(it.url) }
            store.save("session", a)
        }
    }

    private fun tabSheet() {
        val c = col()
        c.addView(button(tr("+ New tab", "+ تبويب جديد")) { newTab() })
        c.addView(
            button(tr("Restore closed tab", "استعادة تبويب مغلق")) {
                if (tabs.closed.isNotEmpty()) newTab(tabs.closed.removeLast())
            }
        )
        tabs.items.toList().forEachIndexed { i, t ->
            val r = row()
            r.addView(
                button("${i+1}  ${t.title.take(28)}") {
                    val actual = tabs.items.indexOf(t)
                    if (actual >= 0) {
                        tabs.index = actual
                        attach()
                    }
                },
                LinearLayout.LayoutParams(0, dp(54), 1f),
            )
            r.addView(
                button("×") {
                    val actual = tabs.items.indexOf(t)
                    if (actual >= 0) {
                        tabs.close(actual)
                        r.visibility = View.GONE
                        if (tabs.items.isEmpty()) newTab()
                        attach()
                    }
                }
            )
            c.addView(r)
        }
        dialog(tr("Tabs", "التبويبات"), ScrollView(this).apply { addView(c) })
    }

    private fun menu() {
        val options =
            listOf(
                tr("New tab", "تبويب جديد"),
                tr("Private browsing", "تصفح خاص"),
                tr("Bookmarks", "المفضلة"),
                tr("History", "السجل"),
                tr("Add bookmark", "إضافة للمفضلة"),
                tr("Share link", "مشاركة الرابط"),
                tr("Find in page", "بحث داخل الصفحة"),
                tr("Desktop site", "موقع سطح المكتب"),
                tr("Downloads", "التنزيلات"),
                tr("Page tools", "أدوات الصفحة"),
                tr("Encrypted link vault", "خزنة الروابط المشفرة"),
                tr("Settings", "الإعدادات"),
            )
        AlertDialog.Builder(this)
            .setItems(options.toTypedArray()) { _, i ->
                when (i) {
                    0 -> newTab()
                    1 -> {
                        if (privateMode) finish()
                        else startActivity(Intent(this, PrivateActivity::class.java))
                    }
                    2 -> library("bookmarks")
                    3 ->
                        if (!privateMode) library("history")
                        else
                            toast(
                                tr(
                                    "History is not saved in private mode",
                                    "لا يُحفظ السجل في الوضع الخاص",
                                )
                            )
                    4 -> {
                        val t = tabs.current
                        if (t != null && t.url.startsWith("http")) {
                            if (privateMode)
                                toast(tr("Disabled in private mode", "معطّل في الوضع الخاص"))
                            else {
                                store.add("bookmarks", t.title, t.url)
                                toast(tr("Saved", "تم الحفظ"))
                            }
                        }
                    }
                    5 -> share(tabs.current?.url ?: "")
                    6 -> ask(tr("Find", "بحث")) { tabs.current?.web?.findAllAsync(it) }
                    7 -> {
                        tabs.current?.web?.apply {
                            val desktop = tag != "desktop"
                            tag = if (desktop) "desktop" else "mobile"
                            settings.userAgentString =
                                if (desktop)
                                    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
                                else WebSettings.getDefaultUserAgent(this@MainActivity)
                            settings.useWideViewPort = desktop
                            settings.loadWithOverviewMode = desktop
                            reload()
                        }
                    }
                    8 -> downloadSheet()
                    9 -> tools()
                    10 ->
                        if (!privateMode) authenticate { vault() }
                        else
                            toast(
                                tr(
                                    "Open the vault from regular browsing",
                                    "افتح الخزنة من التصفح العادي",
                                )
                            )
                    11 -> settings()
                }
            }
            .show()
    }

    private fun share(text: String) {
        if (text.isNotEmpty())
            startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, text)
                    },
                    tr("Share", "مشاركة"),
                )
            )
    }

    private fun library(key: String) {
        val c = col()
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val search = field(tr("Search locally", "بحث محلي"))
        c.addView(search)
        c.addView(results)
        fun render(q: String) {
            results.removeAllViews()
            val a = store.list(key)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                if (!o.toString().contains(q, true)) continue
                val r = row()
                r.addView(
                    button(o.optString("title").take(50)) {
                        if (key == "notes")
                            ask(tr("Note", "ملاحظة"), o.optString("url")) {
                                store.remove(key, i)
                                store.add(key, it.take(60), it)
                            }
                        else newTab(o.optString("url"))
                    },
                    LinearLayout.LayoutParams(0, dp(60), 1f),
                )
                r.addView(
                    button("×") {
                        store.remove(key, i)
                        render(search.text.toString())
                    }
                )
                results.addView(r)
            }
        }
        search.addTextChangedListener(
            object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}

                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                    render(s.toString())
                }

                override fun afterTextChanged(s: android.text.Editable?) {}
            }
        )
        render("")
        dialog(key, ScrollView(this).apply { addView(c) })
    }

    private fun protection() {
        val c = col()
        toggle(c, tr("Enable AdBlock", "تفعيل حظر الإعلانات"), "block", true) {
            tabs.current?.web?.reload()
        }
        toggle(c, tr("Strong cosmetic mode", "إخفاء عناصر إضافية"), "strong", false) {
            tabs.current?.web?.reload()
        }
        c.addView(
            label(
                tr("Recorded blocked requests today: ", "طلبات الحظر المسجلة اليوم: ") +
                    store.prefs.getLong("blocked.${LocalDate.now()}", 0)
            )
        )
        val host = FilterEngine.host(tabs.current?.url ?: "")
        if (host != null)
            c.addView(
                button(tr("Toggle exception for ", "تبديل الاستثناء لـ ") + host) {
                    val set = store.prefs.getStringSet("white", emptySet())!!.toMutableSet()
                    if (!set.add(host)) set.remove(host)
                    store.prefs.edit().putStringSet("white", set).apply()
                    tabs.current?.web?.reload()
                    toast(set.joinToString())
                }
            )
        c.addView(
            label(
                tr("Exceptions: ", "الاستثناءات: ") +
                    store.prefs.getStringSet("white", emptySet())!!.joinToString()
            )
        )
        c.addView(
            button(tr("Edit custom rules", "تحرير القواعد المخصصة")) {
                ask("||example.org^", store.prefs.getString("rules", "")!!) {
                    require(it.length < 200000)
                    store.prefs.edit().putString("rules", it).apply()
                    reloadFilters()
                }
            }
        )
        c.addView(
            button(tr("Update EasyList + EasyPrivacy", "تحديث EasyList وEasyPrivacy")) {
                updateFilters()
            }
        )
        c.addView(
            label(
                tr(
                    "Supported: ||domain^, @@||domain^, third-party, generic ##selectors. Other rules skipped: ",
                    "المدعوم: قواعد النطاقات واستثناءاتها وthird-party ومحددات ## العامة. القواعد المتجاوزة: ",
                ) + filter.unsupported
            )
        )
        dialog(tr("Protection", "الحماية"), ScrollView(this).apply { addView(c) })
    }

    private fun reloadFilters() {
        filter.replace(
            FilterEngine.seed +
                "\n" +
                (if (store.filters.exists()) store.filters.readText() else "") +
                "\n" +
                store.prefs.getString("rules", "")
        )
    }

    private fun updateFilters() {
        toast(tr("Downloading public lists…", "جار تنزيل القوائم العامة…"))
        Thread {
                runCatching {
                        val text =
                            listOf(
                                    "https://easylist.to/easylist/easylist.txt",
                                    "https://easylist.to/easylist/easyprivacy.txt",
                                )
                                .joinToString("\n") { u ->
                                    val conn =
                                        URL(u).openConnection().apply {
                                            connectTimeout = 15000
                                            readTimeout = 20000
                                        }
                                    conn.getInputStream().use {
                                        val b = it.readBounded(8 * 1024 * 1024)
                                        require(b.size <= 8 * 1024 * 1024)
                                        String(b)
                                    }
                                }
                        val tmp = java.io.File(store.filters.path + ".tmp")
                        tmp.writeText(text)
                        check(tmp.renameTo(store.filters))
                        reloadFilters()
                    }
                    .onSuccess {
                        runOnUiThread {
                            toast(
                                tr(
                                    "Lists saved. Unsupported rules: ",
                                    "حُفظت القوائم. قواعد غير مدعومة: ",
                                ) + filter.unsupported
                            )
                        }
                    }
                    .onFailure { runOnUiThread { toast(it.message ?: "Update failed") } }
            }
            .start()
    }

    private fun toggle(
        c: LinearLayout,
        title: String,
        key: String,
        default: Boolean = false,
        changed: () -> Unit = {},
    ) {
        c.addView(
            Switch(this).apply {
                text = title
                setTextColor(fg)
                isChecked = store.prefs.getBoolean(key, default)
                setPadding(dp(8), dp(12), dp(8), dp(12))
                setOnCheckedChangeListener { _, b ->
                    store.prefs.edit().putBoolean(key, b).apply()
                    changed()
                }
            }
        )
    }

    private fun settings() {
        val c = col()
        toggle(c, tr("Light theme", "مظهر فاتح"), "light") {
            light = store.prefs.getBoolean("light", false)
            buildUI()
            attach()
        }
        c.addView(
            button("العربية / English") {
                arabic = !arabic
                store.prefs.edit().putString("language", if (arabic) "ar" else "en").apply()
                buildUI()
                attach()
            }
        )
        c.addView(
            button(tr("Search engine", "محرك البحث")) {
                AlertDialog.Builder(this)
                    .setItems(arrayOf("DuckDuckGo", "Google", "Bing")) { _, i ->
                        store.prefs
                            .edit()
                            .putString("engine", arrayOf("DuckDuckGo", "Google", "Bing")[i])
                            .apply()
                    }
                    .show()
            }
        )
        toggle(c, tr("Disable images (reload page)", "منع الصور (أعد تحميل الصفحة)"), "noImages") {
            tabs.items.forEach {
                it.web.settings.loadsImagesAutomatically =
                    !store.prefs.getBoolean("noImages", false)
            }
        }
        c.addView(
            button(tr("Toggle app lock (biometrics)", "تبديل قفل التطبيق بالبصمة")) {
                authenticate {
                    val enabled = !store.prefs.getBoolean("lock", false)
                    store.prefs.edit().putBoolean("lock", enabled).apply()
                    if (enabled) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                    else if (!privateMode) window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                    toast(
                        if (enabled) tr("App lock enabled", "تم تفعيل القفل")
                        else tr("App lock disabled", "تم تعطيل القفل")
                    )
                }
            }
        )
        c.addView(button(tr("AdBlock settings", "إعدادات الحظر")) { protection() })
        c.addView(button(tr("Privacy & cleanup", "الخصوصية والتنظيف")) { privacy() })
        if (!privateMode) {
            c.addView(
                button(tr("Export bookmarks & notes", "تصدير المفضلة والملاحظات")) {
                    startActivityForResult(
                        Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                            type = "application/json"
                            putExtra(Intent.EXTRA_TITLE, "haider-backup.json")
                            addCategory(Intent.CATEGORY_OPENABLE)
                        },
                        101,
                    )
                }
            )
            c.addView(
                button(
                    tr("Import bookmarks (replaces existing)", "استيراد المفضلة (استبدال الحالية)")
                ) {
                    startActivityForResult(
                        Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            type = "application/json"
                            addCategory(Intent.CATEGORY_OPENABLE)
                        },
                        102,
                    )
                }
            )
        }
        c.addView(
            label(
                "haider Browser 0.2.0\nNative WebView • Local storage\nNo account • No telemetry\nSource & limitations: FEATURES-AND-TESTS.md",
                14f,
            )
        )
        dialog(tr("Settings", "الإعدادات"), ScrollView(this).apply { addView(c) })
    }

    private fun privacy() {
        val c = col()
        c.addView(
            label(
                tr(
                    "Third-party cookies blocked. Site camera, microphone and location denied. TLS errors are never bypassed.",
                    "ملفات الطرف الثالث محظورة. تُمنع الكاميرا والميكروفون والموقع للمواقع. لا يتم تجاوز أخطاء TLS.",
                )
            )
        )
        c.addView(
            button(tr("Delete history", "حذف السجل")) {
                store.save("history", JSONArray())
                tabs.items.forEach { it.web.clearHistory() }
                toast(tr("History deleted", "حُذف السجل"))
            }
        )
        c.addView(
            button(tr("Clear cookies & site storage", "حذف الكوكيز وبيانات المواقع")) {
                CookieManager.getInstance().removeAllCookies {
                    toast(tr("Cookies deleted", "حُذفت الكوكيز"))
                }
                WebStorage.getInstance().deleteAllData()
            }
        )
        c.addView(
            button(tr("Clear cache", "مسح الكاش")) {
                tabs.items.forEach { it.web.clearCache(true) }
                toast(tr("Cache cleared", "تم مسح الكاش"))
            }
        )
        c.addView(
            button(
                if (privateMode) tr("Close all private tabs", "إغلاق كل التبويبات الخاصة")
                else tr("Open private browsing", "فتح التصفح الخاص")
            ) {
                if (privateMode) finish()
                else startActivity(Intent(this, PrivateActivity::class.java))
            }
        )
        dialog(tr("Privacy", "الخصوصية"), c)
    }

    private fun downloadSheet() {
        if (privateMode) {
            toast(tr("Disabled in private mode", "معطّل في الوضع الخاص"))
            return
        }
        val c = col()
        val ids =
            store.prefs.getStringSet("downloadIds", emptySet())!!.mapNotNull { it.toLongOrNull() }
        if (ids.isEmpty()) c.addView(label(tr("No downloads", "لا توجد تنزيلات")))
        ids.forEach { id ->
            downloads.manager.query(DownloadManager.Query().setFilterById(id)).use { cur ->
                if (cur.moveToFirst()) {
                    val title =
                        cur.getString(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE))
                    val done =
                        cur.getLong(
                            cur.getColumnIndexOrThrow(
                                DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR
                            )
                        )
                    val total =
                        cur.getLong(
                            cur.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                        )
                    val status =
                        cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                    val r = row()
                    r.addView(
                        button("$title\n$done / $total B · $status") {
                            val uri = downloads.manager.getUriForDownloadedFile(id)
                            if (uri != null)
                                runCatching {
                                        startActivity(
                                            Intent(Intent.ACTION_VIEW)
                                                .setDataAndType(
                                                    uri,
                                                    downloads.manager.getMimeTypeForDownloadedFile(
                                                        id
                                                    ),
                                                )
                                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        )
                                    }
                                    .onFailure {
                                        toast(
                                            tr("No compatible viewer", "لا يوجد تطبيق لفتح الملف")
                                        )
                                    }
                        },
                        LinearLayout.LayoutParams(0, dp(76), 1f),
                    )
                    r.addView(
                        button("×") {
                            downloads.manager.remove(id)
                            val set =
                                store.prefs.getStringSet("downloadIds", emptySet())!!.toMutableSet()
                            set.remove(id.toString())
                            store.prefs.edit().putStringSet("downloadIds", set).apply()
                            r.visibility = View.GONE
                        }
                    )
                    c.addView(r)
                }
            }
        }
        c.addView(button(tr("Refresh progress", "تحديث التقدم")) { downloadSheet() })
        dialog(
            tr("Downloads • app files", "التنزيلات • ملفات التطبيق"),
            ScrollView(this).apply { addView(c) },
        )
    }

    private fun pageText(done: (String) -> Unit) {
        tabs.current?.web?.evaluateJavascript(
            "document.body ? document.body.innerText.substring(0,100000) : ''"
        ) { raw ->
            runCatching { JSONArray("[$raw]").getString(0) }.onSuccess(done)
        }
    }

    private fun tools() {
        val options =
            arrayOf(
                tr("Word & character count", "عدد الكلمات والحروف"),
                tr("Extract links", "استخراج الروابط"),
                tr("Save page as PDF", "حفظ الصفحة PDF"),
                tr("Read aloud", "قراءة صوتية"),
                tr("Stop reading", "إيقاف القراءة"),
                tr("New note", "ملاحظة جديدة"),
                tr("Notes", "الملاحظات"),
                tr("Link QR code", "رمز QR للرابط"),
                tr("Copy page text", "نسخ نص الصفحة"),
                tr("Local extractive summary", "ملخّص استخراجي محلي"),
            )
        AlertDialog.Builder(this)
            .setItems(options) { _, i ->
                when (i) {
                    0 ->
                        pageText {
                            dialog(
                                tr("Text statistics", "إحصائيات النص"),
                                label(
                                    "${it.split(Regex("\\s+")).count{w->w.isNotBlank()}} words • ${it.length} characters"
                                ),
                            )
                        }
                    1 ->
                        tabs.current?.web?.evaluateJavascript(
                            "JSON.stringify(Array.from(document.links).slice(0,300).map(a=>a.href))"
                        ) { raw ->
                            ask(
                                tr("Links", "الروابط"),
                                runCatching { JSONArray("[$raw]").getString(0) }.getOrDefault(""),
                            ) {}
                        }
                    2 -> {
                        tabs.current?.web?.let {
                            (getSystemService(PRINT_SERVICE) as PrintManager).print(
                                "haider-page",
                                it.createPrintDocumentAdapter("haider-page"),
                                null,
                            )
                        }
                    }
                    3 ->
                        pageText { txt ->
                            if (ttsReady)
                                tts?.speak(
                                    txt.take(4000),
                                    TextToSpeech.QUEUE_FLUSH,
                                    null,
                                    "article",
                                )
                            else {
                                tts =
                                    TextToSpeech(this) { s ->
                                        ttsReady = s == TextToSpeech.SUCCESS
                                        if (ttsReady) {
                                            tts?.language =
                                                if (arabic) Locale.forLanguageTag("ar")
                                                else Locale.ENGLISH
                                            tts?.speak(
                                                txt.take(4000),
                                                TextToSpeech.QUEUE_FLUSH,
                                                null,
                                                "article",
                                            )
                                        }
                                    }
                            }
                        }
                    4 -> tts?.stop()
                    5 ->
                        if (!privateMode)
                            ask(tr("Note", "ملاحظة")) { store.add("notes", it.take(60), it) }
                        else toast(tr("Disabled in private mode", "معطّل في الوضع الخاص"))
                    6 ->
                        if (!privateMode) library("notes")
                        else toast(tr("Disabled in private mode", "معطّل في الوضع الخاص"))
                    7 -> qr()
                    8 ->
                        pageText {
                            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                                .setPrimaryClip(ClipData.newPlainText("Page text", it))
                            toast(tr("Copied", "تم النسخ"))
                        }
                    9 ->
                        pageText {
                            val sentences = it.split(Regex("(?<=[.!?؟])\\s+"))
                            val ranked =
                                sentences
                                    .withIndex()
                                    .sortedByDescending { x ->
                                        x.value.split(Regex("\\s+")).distinct().size
                                    }
                                    .take(3)
                                    .sortedBy { it.index }
                            dialog(
                                tr(
                                    "Extractive summary — no AI model",
                                    "ملخّص استخراجي — دون نموذج AI",
                                ),
                                ScrollView(this).apply {
                                    addView(
                                        label(ranked.joinToString("\n") { it.value }.take(6000))
                                    )
                                },
                            )
                        }
                }
            }
            .show()
    }

    private fun qr() {
        val u = tabs.current?.url ?: return
        if (u.isEmpty() || u.length > 1500) return
        runCatching {
                val matrix = MultiFormatWriter().encode(u, BarcodeFormat.QR_CODE, 640, 640)
                val pixels =
                    IntArray(640 * 640) { i ->
                        if (matrix[i % 640, i / 640]) Color.BLACK else Color.WHITE
                    }
                val b = Bitmap.createBitmap(pixels, 640, 640, Bitmap.Config.ARGB_8888)
                dialog(
                    "QR",
                    ImageView(this).apply {
                        setImageBitmap(b)
                        adjustViewBounds = true
                    },
                )
            }
            .onFailure { toast(it.message ?: "QR error") }
    }

    private fun vault() {
        runCatching {
                val vault = LinkVault(this)
                val value = vault.read()
                val editor = field(tr("Encrypted links", "روابط مشفرة"), value)
                window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                sensitiveDialog =
                    AlertDialog.Builder(this)
                        .setTitle(
                            tr("Encrypted links — one per line", "روابط مشفرة — رابط لكل سطر")
                        )
                        .setView(editor)
                        .setPositiveButton(tr("Save", "حفظ")) { _, _ ->
                            runCatching { vault.save(editor.text.toString()) }
                                .onFailure { toast(it.message ?: "Vault error") }
                        }
                        .setNegativeButton(tr("Cancel", "إلغاء"), null)
                        .create()
                        .apply {
                            window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                            setOnDismissListener {
                                editor.setText("")
                                sensitiveDialog = null
                                if (!privateMode && !store.prefs.getBoolean("lock", false))
                                    this@MainActivity.window.clearFlags(
                                        WindowManager.LayoutParams.FLAG_SECURE
                                    )
                            }
                            show()
                        }
            }
            .onFailure { toast(tr("Vault could not be unlocked", "تعذّر فتح الخزنة")) }
    }

    private fun authenticate(done: () -> Unit) {
        if (authBusy) return
        authBusy = true
        BiometricPrompt.Builder(this)
            .setTitle(tr("Unlock haider Browser", "فتح haider Browser"))
            .setSubtitle(tr("Use a registered biometric", "استخدم البصمة المسجلة"))
            .setNegativeButton(tr("Cancel", "إلغاء"), mainExecutor) { _, _ -> authBusy = false }
            .build()
            .authenticate(
                CancellationSignal(),
                mainExecutor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(
                        result: BiometricPrompt.AuthenticationResult
                    ) {
                        authBusy = false
                        locked = false
                        done()
                    }

                    override fun onAuthenticationError(code: Int, msg: CharSequence) {
                        authBusy = false
                        toast(msg.toString())
                    }
                },
            )
    }

    override fun onPause() {
        sensitiveDialog?.dismiss()
        super.onPause()
        tabs.items.forEach { it.web.onPause() }
        tts?.stop()
        if (store.prefs.getBoolean("lock", false)) {
            locked = true
            content.visibility = View.INVISIBLE
        }
        saveSession()
    }

    override fun onResume() {
        super.onResume()
        if (locked || (!resumedOnce && store.prefs.getBoolean("lock", false))) {
            locked = true
            content.visibility = View.INVISIBLE
            authenticate {
                content.visibility = View.VISIBLE
                tabs.current?.web?.onResume()
            }
        } else tabs.current?.web?.onResume()
        resumedOnce = true
    }

    override fun dispatchTouchEvent(event: android.view.MotionEvent): Boolean {
        if (locked && event.action == android.view.MotionEvent.ACTION_DOWN) {
            authenticate { content.visibility = View.VISIBLE }
            return true
        }
        return super.dispatchTouchEvent(event)
    }

    override fun onDestroy() {
        upload?.onReceiveValue(null)
        upload = null
        tts?.shutdown()
        if (privateMode) {
            tabs.items.forEach {
                it.web.clearCache(true)
                it.web.clearHistory()
                it.web.destroy()
            }
            CookieManager.getInstance().removeAllCookies(null)
            WebStorage.getInstance().deleteAllData()
            cacheDir.deleteRecursively()
        }
        super.onDestroy()
    }

    @Deprecated("Platform callback")
    override fun onBackPressed() {
        if (fullscreen != null) {
            exitFullscreen()
            return
        }
        val w = tabs.current?.web
        if (w?.canGoBack() == true) w.goBack()
        else if (privateMode) finish()
        else {
            tabs.current?.url = ""
            attach()
        }
    }

    @Deprecated("Platform result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 104) {
            upload?.onReceiveValue(
                if (resultCode == RESULT_OK) data?.data?.let { arrayOf(it) } else null
            )
            upload = null
            return
        }
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        runCatching {
                when (requestCode) {
                    101 ->
                        contentResolver.openOutputStream(uri)?.bufferedWriter()?.use {
                            it.write(store.export())
                        }
                    102 ->
                        contentResolver.openInputStream(uri)?.use {
                            val b = it.readBounded(2 * 1024 * 1024)
                            require(b.size <= 2 * 1024 * 1024)
                            store.import(String(b, Charsets.UTF_8))
                        }
                }
            }
            .onSuccess { toast(tr("Done", "تم")) }
            .onFailure { toast(it.message ?: "Error") }
    }
}
