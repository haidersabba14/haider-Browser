package com.haider.browser.downloads

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.webkit.CookieManager
import android.webkit.URLUtil

class DownloadController(private val context: Context) {
    val manager = context.getSystemService(DownloadManager::class.java)

    fun enqueue(
        url: String,
        agent: String?,
        disposition: String?,
        mime: String?,
        privateMode: Boolean,
    ): Long {
        require(!privateMode) { "Downloads are disabled in private browsing" }
        require(Uri.parse(url).scheme in listOf("https", "http")) {
            "Only HTTP(S) downloads are supported"
        }
        val filename =
            URLUtil.guessFileName(url, disposition, mime).replace(Regex("[\\\\/:*?\"<>|]"), "_")
        val request =
            DownloadManager.Request(Uri.parse(url))
                .setTitle(filename)
                .setMimeType(mime)
                .setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                )
                .setDestinationInExternalFilesDir(
                    context,
                    Environment.DIRECTORY_DOWNLOADS,
                    filename,
                )
        agent?.let { request.addRequestHeader("User-Agent", it) }
        CookieManager.getInstance().getCookie(url)?.let { request.addRequestHeader("Cookie", it) }
        return manager.enqueue(request)
    }
}
