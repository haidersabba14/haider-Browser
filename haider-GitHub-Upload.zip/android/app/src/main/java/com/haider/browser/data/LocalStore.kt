package com.haider.browser.data

import android.content.Context
import java.io.File
import org.json.JSONArray
import org.json.JSONObject

class LocalStore(context: Context) {
    val prefs = context.getSharedPreferences("browser", Context.MODE_PRIVATE)
    val filters = File(context.filesDir, "filters.txt")

    fun list(key: String): JSONArray =
        runCatching { JSONArray(prefs.getString(key, "[]")) }.getOrDefault(JSONArray())

    fun save(key: String, data: JSONArray) {
        prefs.edit().putString(key, data.toString()).apply()
    }

    @Synchronized
    fun add(key: String, title: String, url: String) {
        val old = list(key)
        val next = JSONArray()
        next.put(
            JSONObject().put("title", title).put("url", url).put("time", System.currentTimeMillis())
        )
        for (i in 0 until old.length()) if (
            old.getJSONObject(i).optString("url") != url && next.length() < 1000
        )
            next.put(old[i])
        save(key, next)
    }

    fun remove(key: String, index: Int) {
        val a = list(key)
        a.remove(index)
        save(key, a)
    }

    fun export(): String =
        JSONObject()
            .put("format", "haider-browser-1")
            .put("bookmarks", list("bookmarks"))
            .put("notes", list("notes"))
            .toString(2)

    fun import(text: String) {
        val data = JSONObject(text)
        require(data.getString("format") == "haider-browser-1")
        val a = data.getJSONArray("bookmarks")
        require(a.length() <= 1000)
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val u = o.getString("url")
            require(u.length < 8192 && (u.startsWith("https://") || u.startsWith("http://")))
        }
        save("bookmarks", a)
    }
}
