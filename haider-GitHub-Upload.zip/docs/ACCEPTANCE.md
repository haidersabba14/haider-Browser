# Remaining device acceptance — not claimed as executed

Use a test profile/device. iOS requires the first Xcode build and type check before all these steps.

1. Open example.org, wikipedia.org, Arabic and English searches with all three engines; follow redirects and check the address field, navigation, reload, errors and invalid TLS certificates.
2. Open 20 tabs, close several, restore closed, relaunch and verify only regular tabs restore. Check private isolation with same-site cookies in normal and private browsing; terminate private mode normally and force-stop/crash, then verify cleanup on next launch.
3. Run the local integration fixture with a custom `||127.0.0.1^` rule. Confirm actual blocking, cosmetic hide, exception, global off and filter updates. Test unsupported rule reporting and offline cached rules. iOS must compile the real rule list on WebKit.
4. Authenticate to link vault, save/read, reject auth, background with vault open, relaunch with lock on, test Face ID/Touch ID/Android biometrics and enrollment changes. Verify vault corruption gives error and no silent overwrite. Test devices without enrollment before enabling lock.
5. Visit a site that requests media or location; confirm denial. Check third-party cookies on Android and system WebKit restrictions on iOS. Inspect private app-switcher previews.
6. Download a permitted PDF, image and media file with cookies/auth; progress, complete, cancel, fail, open and delete. iOS download completion with app backgrounded is not guaranteed. Verify downloads do not persist from private mode.
7. Export/import bookmarks, including malformed and oversized files. Note that import replaces existing bookmarks and formats currently differ across platforms. Try notes, search and text selection; there is no whole-app restore.
8. Play HTML5 video and audio, enter/leave fullscreen and PiP where available. Try external downloaded media viewers; there is no standalone playlist/local media library or guaranteed background playback.
9. Try PDF export, QR generation, text/links extraction, counters, summary and speech. Speech depends on installed system voices; no remote voice model is bundled. No offline translation or OCR is present.
10. Review RTL/LTR on small phones and tablets, light/dark themes, accessibility labels, font sizes, keyboard, rotation, insets, memory/battery over long sessions and download notification behavior.

Production release additionally needs real-device regression, iOS build/archiving/signing checks, a broader site compatibility suite, dependency/security review and review of filter-list license obligations if redistributing downloaded lists.
