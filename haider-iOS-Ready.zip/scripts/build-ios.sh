#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v xcodebuild >/dev/null || { echo 'macOS with Xcode is required.' >&2; exit 1; }
mkdir -p dist
if [[ "${1:-}" == "--unsigned" ]]; then
 xcodebuild -project ios/HaiderBrowser.xcodeproj -scheme 'haider Browser' -configuration Release -destination 'generic/platform=iOS' -archivePath "$PWD/dist/haider.xcarchive" CODE_SIGNING_ALLOWED=NO archive
 app="$PWD/dist/haider.xcarchive/Products/Applications/haider Browser.app"
 file "$app/haider Browser" | grep -q 'Mach-O' || { echo 'Missing compiled Mach-O executable' >&2; exit 1; }
 tmp=$(mktemp -d)
 mkdir -p "$tmp/Payload"
 ditto "$app" "$tmp/Payload/haider Browser.app"
 destination="$PWD/dist/haider-Browser-unsigned.ipa"
 (cd "$tmp" && /usr/bin/zip -qry "$destination" Payload)
 echo 'Unsigned IPA: does not install through standard iOS signing. Requires a compatible signing/install route.'
else
 : "${HAIDER_TEAM_ID:?Set your Apple development team identifier}"
 : "${HAIDER_EXPORT_OPTIONS:?Set path to your own ExportOptions.plist}"
 xcodebuild -project ios/HaiderBrowser.xcodeproj -scheme 'haider Browser' -configuration Release -destination 'generic/platform=iOS' -archivePath "$PWD/dist/haider.xcarchive" DEVELOPMENT_TEAM="$HAIDER_TEAM_ID" -allowProvisioningUpdates archive
 xcodebuild -exportArchive -archivePath "$PWD/dist/haider.xcarchive" -exportPath "$PWD/dist/ios-export" -exportOptionsPlist "$HAIDER_EXPORT_OPTIONS" -allowProvisioningUpdates
 python3 - <<'PY'
from pathlib import Path
import shutil
files=list(Path('dist/ios-export').glob('*.ipa'))
assert len(files)==1, 'Expected one exported IPA'
shutil.copy2(files[0],'dist/haider-Browser.ipa')
PY
fi
