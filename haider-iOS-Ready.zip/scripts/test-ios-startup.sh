#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v xcodebuild >/dev/null || { echo 'This test requires macOS and Xcode.' >&2; exit 1; }
mkdir -p dist
python3 tests/ios_fixture_server.py > dist/ios-fixture.log 2>&1 &
HAIDER_FIXTURE_PID=$!
trap 'kill "$HAIDER_FIXTURE_PID" 2>/dev/null || true' EXIT
HAIDER_SIMULATOR=$(xcrun simctl list devices available -j | python3 -c '
import json,sys,re
obj=json.load(sys.stdin)["devices"]
for runtime in sorted(obj, key=lambda s:tuple(map(int,re.findall(r"\d+",s))), reverse=True):
 if ".iOS-" not in runtime:continue
 for device in obj[runtime]:
  if device.get("isAvailable",True) and device["name"].startswith("iPhone"):
   print(device["udid"]);sys.exit(0)
raise SystemExit("No available iPhone simulator")')
xcrun simctl boot "$HAIDER_SIMULATOR" 2>/dev/null || true
xcrun simctl bootstatus "$HAIDER_SIMULATOR" -b
xcodebuild -project ios/HaiderBrowser.xcodeproj -scheme 'haider Browser' \
 -configuration Debug -destination "platform=iOS Simulator,id=$HAIDER_SIMULATOR" \
 -derivedDataPath "$PWD/dist/SimulatorDerivedData" -resultBundlePath "$PWD/dist/ios-startup.xcresult" \
 -parallel-testing-enabled NO CODE_SIGNING_ALLOWED=NO test 2>&1 | tee dist/ios-startup-test.log
