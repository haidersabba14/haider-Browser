import SwiftUI

struct PremiumStartView: View {
    let ar: Bool
    let light: Bool
    let privateMode: Bool
    let protectionEnabled: Bool
    @Binding var query: String
    let search: () -> Void
    let navigate: (String) -> Void
    let protection: () -> Void
    let downloads: () -> Void
    let privacy: () -> Void
    let settings: () -> Void
    let bookmarks: () -> Void
    private var ink: Color { light ? .black : .white }
    private var muted: Color { light ? .black.opacity(0.5) : .white.opacity(0.48) }
    private var surface: Color { light ? .white : Color(red: 0.085, green: 0.09, blue: 0.10) }
    private func t(_ en: String, _ arabic: String) -> String { ar ? arabic : en }
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 0) {
                HStack(spacing: 11) {
                    Image(systemName: "crown").font(.system(size: 18, weight: .medium)).foregroundStyle(Color.haiderGold)
                        .frame(width: 38, height: 38).background(Color.haiderGold.opacity(0.09), in: RoundedRectangle(cornerRadius: 13))
                    Text("haider Browser").font(.system(size: 17, weight: .medium)).foregroundStyle(ink)
                    Spacer()
                    Button(action: settings) { Image(systemName: privateMode ? "lock" : "gearshape").font(.system(size: 19)).foregroundStyle(muted).frame(width: 40, height: 40) }.accessibilityLabel(t("Settings", "الإعدادات"))
                }
                PremiumOrbit().frame(height: 104).padding(.top, 13)
                Text(privateMode ? t("PRIVATE BROWSING", "تصفح خاص") : t("A LITTLE MORE FREEDOM", "مساحة أوسع لحريتك"))
                    .font(.system(size: 10, weight: .medium)).tracking(ar ? 0 : 2).foregroundStyle(Color.haiderGold).padding(.top, 7)
                Text(privateMode ? t("A moment.\nJust for you.", "لحظتك.\nبخصوصية أكبر.") : t("Explore more.\nLeave less behind.", "اكتشف أكثر.\nاترك أثرًا أقل."))
                    .font(.system(size: 34, weight: .light)).lineSpacing(2).multilineTextAlignment(.center).foregroundStyle(ink).padding(.top, 13)
                Text(t("Your next discovery starts here.", "كل اكتشاف جديد يبدأ من هنا.")).font(.system(size: 13)).foregroundStyle(muted).padding(.top, 12)
                HStack(spacing: 12) {
                    Image(systemName: "magnifyingglass").font(.system(size: 18)).foregroundStyle(muted)
                    TextField(t("Search or enter a URL", "ابحث أو أدخل رابطًا"), text: $query)
                        .font(.system(size: 14)).foregroundStyle(ink).keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled().submitLabel(.go).onSubmit(search)
                    Button(action: search) { Image(systemName: ar ? "arrow.left" : "arrow.right").font(.system(size: 16, weight: .medium)).foregroundStyle(Color.haiderBlack).frame(width: 42, height: 42).background(Color.haiderGold, in: RoundedRectangle(cornerRadius: 13)) }.accessibilityLabel(t("Search", "بحث"))
                }.padding(.leading, 17).padding(.trailing, 8).frame(height: 62).background(surface, in: RoundedRectangle(cornerRadius: 18)).overlay(RoundedRectangle(cornerRadius: 18).strokeBorder(ink.opacity(0.08))).padding(.top, 25)
                Button(action: protection) {
                    VStack(alignment: .leading, spacing: 15) {
                        HStack(spacing: 8) {
                            Image(systemName: "checkmark.shield").foregroundStyle(Color.haiderGold)
                            Text("haider AdBlock PRO").font(.system(size: 13, weight: .medium)).foregroundStyle(ink)
                            Spacer()
                            Text(protectionEnabled ? t("ON", "مفعّل") : t("OFF", "متوقف")).font(.system(size: 9, weight: .semibold)).tracking(ar ? 0 : 1).foregroundStyle(Color.haiderGold).padding(.horizontal, 10).padding(.vertical, 5).background(Color.haiderGold.opacity(0.12), in: Capsule())
                        }
                        HStack(alignment: .center) {
                            VStack(alignment: .leading, spacing: 5) {
                                Text(privateMode ? t("A private space.", "مساحتك الخاصة.") : t("Protection, built in.", "حماية في قلب التجربة.")).font(.system(size: 20, weight: .light)).foregroundStyle(ink)
                                Text(privateMode ? t("Your session stays out of history.", "لا تُحفظ الجلسة الخاصة في السجل.") : t("Known ads & trackers. Fewer distractions.", "حظر إعلانات وتتبّع معروفين. تشتيت أقل.")).font(.system(size: 11)).foregroundStyle(muted)
                            }
                            Spacer(); Image(systemName: ar ? "chevron.left" : "chevron.right").font(.system(size: 12)).foregroundStyle(Color.haiderGold)
                        }
                    }.padding(18).background(LinearGradient(colors: [Color.haiderGold.opacity(light ? 0.13 : 0.12), surface], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 21)).overlay(RoundedRectangle(cornerRadius: 21).strokeBorder(Color.haiderGold.opacity(0.2)))
                }.buttonStyle(.plain).padding(.top, 23)
                HStack { Text(t("Your shortcuts", "اختصاراتك")).font(.system(size: 14, weight: .medium)).foregroundStyle(ink); Spacer(); Button(t("Bookmarks", "المفضلة"), action: bookmarks).font(.system(size: 12)).foregroundStyle(Color.haiderGold) }.padding(.top, 25)
                HStack(spacing: 0) {
                    shortcut("W", "Wikipedia", "https://wikipedia.org", ink)
                    shortcut("D", "DuckDuckGo", "https://duckduckgo.com", Color(red: 0.88, green: 0.55, blue: 0.35))
                    shortcut("G", "Google", "https://google.com", Color(red: 0.47, green: 0.65, blue: 0.94))
                    shortcut("▶", "YouTube", "https://youtube.com", Color(red: 0.9, green: 0.44, blue: 0.42))
                }.padding(.top, 15)
                HStack {
                    utility("arrow.down.to.line", t("Downloads", "التنزيلات"), downloads)
                    utility("lock", t("Privacy", "الخصوصية"), privacy)
                    utility("gearshape", t("Settings", "الإعدادات"), settings)
                }.padding(.top, 23)
                Text(t("NO ACCOUNT. NO APP ADS. JUST YOUR WEB.", "بلا حساب. بلا إعلانات داخل التطبيق.")).font(.system(size: 8)).tracking(ar ? 0 : 1).foregroundStyle(muted).padding(.top, 23)
            }.padding(.horizontal, 24).padding(.top, 12).padding(.bottom, 26).frame(maxWidth: 560)
        }.frame(maxWidth: .infinity)
    }
    private func shortcut(_ mark: String, _ title: String, _ url: String, _ color: Color) -> some View {
        Button { navigate(url) } label: {
            VStack(spacing: 9) { Text(mark).font(.system(size: 22, weight: .medium)).foregroundStyle(color).frame(width: 51, height: 51).background(surface, in: RoundedRectangle(cornerRadius: 16)).overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(ink.opacity(0.07))); Text(title).font(.system(size: 10)).foregroundStyle(muted) }.frame(maxWidth: .infinity)
        }.buttonStyle(.plain)
    }
    private func utility(_ icon: String, _ title: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) { VStack(spacing: 10) { Image(systemName: icon).font(.system(size: 18)); Text(title).font(.system(size: 11)) }.foregroundStyle(muted).frame(maxWidth: .infinity).frame(height: 60) }.buttonStyle(.plain)
    }
}
private struct PremiumOrbit: View {
    var body: some View {
        GeometryReader { geometry in
            let h = geometry.size.height
            ZStack {
                Circle().fill(RadialGradient(colors: [Color.haiderGold.opacity(0.12), .clear], center: .center, startRadius: 0, endRadius: h * 0.65)).frame(width: h * 1.3, height: h * 1.3)
                Circle().stroke(Color.haiderGold.opacity(0.12), lineWidth: 0.6).frame(width: h * 0.9, height: h * 0.9)
                Ellipse().stroke(Color.haiderGold.opacity(0.27), lineWidth: 0.7).frame(width: h * 1.8, height: h * 0.52).rotationEffect(.degrees(-18))
                Ellipse().stroke(Color.haiderGold.opacity(0.13), lineWidth: 0.6).frame(width: h * 1.4, height: h * 0.8).rotationEffect(.degrees(23))
                Circle().fill(LinearGradient(colors: [Color(red: 0.21, green: 0.18, blue: 0.12), Color.haiderBlack], startPoint: .topLeading, endPoint: .bottomTrailing)).frame(width: h * 0.55, height: h * 0.55).overlay(Circle().stroke(Color.haiderGold.opacity(0.6), lineWidth: 0.6))
                Image(systemName: "crown").font(.system(size: h * 0.25, weight: .light)).foregroundStyle(Color(red: 0.88, green: 0.78, blue: 0.44))
                Circle().fill(Color.haiderGold).frame(width: 4, height: 4).offset(x: h * 0.7, y: -h * 0.2)
                Circle().fill(Color.haiderGold.opacity(0.6)).frame(width: 3, height: 3).offset(x: -h * 0.5, y: h * 0.3)
            }.frame(maxWidth: .infinity, maxHeight: .infinity)
        }.accessibilityHidden(true)
    }
}
