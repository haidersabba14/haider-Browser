package com.haider.browser

import android.content.*
import android.net.Uri
import android.os.SystemClock
import android.view.*
import android.webkit.WebView
import androidx.test.core.app.ActivityScenario
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.*
import com.haider.browser.ui.MainActivity
import java.time.LocalDate
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import org.junit.*
import org.junit.Assert.*

class BrowserIntegrationTest {
    private val instrumentation = InstrumentationRegistry.getInstrumentation()
    private val context
        get() = instrumentation.targetContext

    private fun web(v: View): WebView? {
        if (v is WebView) return v
        if (v is ViewGroup)
            for (i in 0 until v.childCount) {
                web(v.getChildAt(i))?.let {
                    return it
                }
            }
        return null
    }

    private fun js(scenario: ActivityScenario<MainActivity>, script: String): String {
        var value = ""
        val latch = CountDownLatch(1)
        scenario.onActivity { a ->
            val w = web(a.window.decorView)
            if (w == null) latch.countDown()
            else
                w.evaluateJavascript(script) {
                    value = it
                    latch.countDown()
                }
        }
        assertTrue(latch.await(10, TimeUnit.SECONDS))
        return value
    }

    private fun waitUntil(f: () -> Boolean) {
        val until = SystemClock.elapsedRealtime() + 45000
        while (SystemClock.elapsedRealtime() < until) {
            if (f()) return
            SystemClock.sleep(300)
        }
        fail("Timed out waiting for WebView condition")
    }

    @Test
    fun realPageBlockingWhitelistAndSession() {
        val prefs = context.getSharedPreferences("browser", Context.MODE_PRIVATE)
        prefs
            .edit()
            .clear()
            .putString("rules", "||127.0.0.1^")
            .putString("language", "en")
            .putBoolean("block", true)
            .commit()
        val intent =
            Intent(context, MainActivity::class.java)
                .setData(Uri.parse("http://localhost:8787/"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ActivityScenario.launch<MainActivity>(intent).use { scenario ->
            val device = UiDevice.getInstance(instrumentation)
            assertTrue(
                device.wait(
                    Until.hasObject(By.text(java.util.regex.Pattern.compile("(?i)continue"))),
                    30000,
                )
            )
            device.findObject(By.text(java.util.regex.Pattern.compile("(?i)continue"))).click()
            waitUntil { js(scenario, "document.title") == "\"Haider integration fixture\"" }
            waitUntil {
                js(scenario, "getComputedStyle(document.getElementById('ad')).display") ==
                    "\"none\""
            }
            val key = "blocked.${LocalDate.now()}"
            assertTrue("Actual intercepted request increments counter", prefs.getLong(key, 0) > 0)
            assertEquals("0", js(scenario, "document.getElementById('pixel').naturalWidth"))
            val count = prefs.getLong(key, 0)
            prefs.edit().putStringSet("white", setOf("localhost")).commit()
            scenario.onActivity { web(it.window.decorView)!!.reload() }
            waitUntil { js(scenario, "document.getElementById('pixel').naturalWidth") == "1" }
            assertEquals("Whitelisted request not counted", count, prefs.getLong(key, 0))
            assertTrue(prefs.getString("session", "")!!.contains("localhost"))
            assertTrue(prefs.getString("history", "")!!.contains("Haider integration fixture"))
            device.findObject(By.desc("Menu")).click()
            assertTrue(device.wait(Until.hasObject(By.text("Add bookmark")), 10000))
            device.findObject(By.text("Add bookmark")).click()
            waitUntil { prefs.getString("bookmarks", "")!!.contains("Haider integration fixture") }
            requireNotNull(device.wait(Until.findObject(By.desc("Tabs")), 15000)).click()
            assertTrue(device.wait(Until.hasObject(By.text("+ New tab")), 10000))
            device.findObject(By.text("+ New tab")).click()
            requireNotNull(
                    device.wait(
                        Until.findObject(By.text(java.util.regex.Pattern.compile("(?i)close"))),
                        15000,
                    )
                )
                .click()
            waitUntil { device.findObject(By.desc("Tabs"))?.text == "2" }
            assertTrue(device.hasObject(By.text("haider Browser")))
            val input =
                requireNotNull(
                    device.wait(Until.findObject(By.clazz("android.widget.EditText")), 15000)
                )
            input.click()
            input.text = "http://localhost:8787/"
            device.pressEnter()
            val confirm = By.text(java.util.regex.Pattern.compile("(?i)continue"))
            requireNotNull(device.wait(Until.findObject(confirm), 15000)).click()
            assertTrue(
                "Enter must not create duplicate HTTP warnings",
                device.wait(Until.gone(confirm), 15000),
            )
            waitUntil { js(scenario, "document.title") == "\"Haider integration fixture\"" }
            assertEquals(
                "2",
                requireNotNull(device.wait(Until.findObject(By.desc("Tabs")), 15000)).text,
            )
        }
    }
}
