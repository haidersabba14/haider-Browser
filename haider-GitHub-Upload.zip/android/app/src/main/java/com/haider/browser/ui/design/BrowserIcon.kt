package com.haider.browser.ui.design

import android.graphics.*
import android.graphics.drawable.Drawable

/** Consistent, original 24-unit stroke icons. No font glyphs or downloaded assets. */
class BrowserIcon(private val name: String, private val tint: Int, private val pixels: Int) :
    Drawable() {
    private val pen =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = tint
            style = Paint.Style.STROKE
            strokeWidth = 1.65f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }

    override fun getIntrinsicWidth() = pixels

    override fun getIntrinsicHeight() = pixels

    override fun draw(canvas: Canvas) {
        val save = canvas.save()
        canvas.translate(bounds.left.toFloat(), bounds.top.toFloat())
        canvas.scale(bounds.width() / 24f, bounds.height() / 24f)
        fun path(vararg xy: Float) {
            val p = Path()
            p.moveTo(xy[0], xy[1])
            for (i in 2 until xy.size step 2) p.lineTo(xy[i], xy[i + 1])
            canvas.drawPath(p, pen)
        }
        fun line(a: Float, b: Float, c: Float, d: Float) = canvas.drawLine(a, b, c, d, pen)
        fun box(l: Float, t: Float, r: Float, b: Float, radius: Float = 3f) =
            canvas.drawRoundRect(l, t, r, b, radius, radius, pen)
        when (name) {
            "back" -> path(14f, 6f, 8f, 12f, 14f, 18f)
            "forward" -> path(10f, 6f, 16f, 12f, 10f, 18f)
            "home" -> {
                path(3f, 10f, 12f, 3f, 21f, 10f)
                path(5f, 9f, 5f, 20f, 10f, 20f, 10f, 14f, 14f, 14f, 14f, 20f, 19f, 20f, 19f, 9f)
            }
            "tabs" -> {
                box(6f, 3f, 21f, 18f)
                box(3f, 6f, 18f, 21f)
            }
            "menu" -> {
                line(4f, 7f, 20f, 7f)
                line(4f, 12f, 20f, 12f)
                line(4f, 17f, 14f, 17f)
            }
            "shield" -> {
                path(
                    12f,
                    2.5f,
                    20f,
                    6f,
                    19f,
                    14f,
                    16f,
                    18.5f,
                    12f,
                    21.5f,
                    8f,
                    18.5f,
                    5f,
                    14f,
                    4f,
                    6f,
                    12f,
                    2.5f,
                )
                path(8.5f, 11.5f, 11f, 14f, 15.5f, 9.5f)
            }
            "search" -> {
                canvas.drawCircle(10.5f, 10.5f, 6.5f, pen)
                line(15.5f, 15.5f, 21f, 21f)
            }
            "reload" -> {
                canvas.drawArc(4f, 4f, 20f, 20f, 30f, 292f, false, pen)
                path(15f, 3f, 20f, 4f, 19f, 9f)
            }
            "download" -> {
                path(12f, 3f, 12f, 15f)
                path(7f, 10f, 12f, 15f, 17f, 10f)
                path(4f, 15f, 4f, 21f, 20f, 21f, 20f, 15f)
            }
            "bookmark" -> path(6f, 3f, 18f, 3f, 18f, 21f, 12f, 17f, 6f, 21f, 6f, 3f)
            "settings" -> {
                canvas.drawCircle(12f, 12f, 3.5f, pen)
                for (i in 0..7) {
                    val a = i * Math.PI / 4
                    line(
                        (12 + 8 * kotlin.math.cos(a)).toFloat(),
                        (12 + 8 * kotlin.math.sin(a)).toFloat(),
                        (12 + 10 * kotlin.math.cos(a)).toFloat(),
                        (12 + 10 * kotlin.math.sin(a)).toFloat(),
                    )
                }
                canvas.drawCircle(12f, 12f, 8f, pen)
            }
            "private" -> {
                box(5f, 10f, 19f, 21f)
                canvas.drawArc(8f, 2f, 16f, 16f, 180f, 180f, false, pen)
                line(12f, 14f, 12f, 17f)
            }
            "arrow" -> {
                line(5f, 12f, 19f, 12f)
                path(14f, 7f, 19f, 12f, 14f, 17f)
            }
            "globe" -> {
                canvas.drawCircle(12f, 12f, 9f, pen)
                canvas.drawOval(8f, 3f, 16f, 21f, pen)
                line(3f, 12f, 21f, 12f)
            }
            "crown" -> {
                path(3f, 7f, 7.5f, 11f, 12f, 4f, 16.5f, 11f, 21f, 7f, 18.5f, 18f, 5.5f, 18f, 3f, 7f)
                line(6f, 21f, 18f, 21f)
            }
        }
        canvas.restoreToCount(save)
    }

    override fun setAlpha(alpha: Int) {
        pen.alpha = alpha
    }

    override fun setColorFilter(filter: ColorFilter?) {
        pen.colorFilter = filter
    }

    @Deprecated("Drawable API") override fun getOpacity() = PixelFormat.TRANSLUCENT
}
