package com.haider.browser.adblock

import java.net.URI
import java.util.Locale

/**
 * Deliberately bounded ABP subset. Unsupported syntax is reported, never silently reinterpreted.
 */
class FilterEngine {
    data class Rule(val host: String, val allow: Boolean, val thirdParty: Boolean)

    data class Parsed(val rules: List<Rule>, val selectors: List<String>, val unsupported: Int)

    private val lock = Any()
    private var rules: List<Rule> = emptyList()
    private var selectors: List<String> = emptyList()
    var unsupported = 0
        private set

    fun replace(text: String) {
        val p = parse(text)
        synchronized(lock) {
            rules = p.rules
            selectors = p.selectors
            unsupported = p.unsupported
        }
    }

    fun blocked(
        url: String,
        page: String,
        enabled: Boolean = true,
        whitelist: Set<String> = emptySet(),
    ): Boolean {
        if (!enabled) return false
        val host = host(url) ?: return false
        val top = host(page) ?: return false
        if (whitelist.any { matches(top, it) }) return false
        val found =
            synchronized(lock) {
                rules.filter { matches(host, it.host) && (!it.thirdParty || !matches(host, top)) }
            }
        return found.any { !it.allow } && found.none { it.allow }
    }

    fun css(strong: Boolean): String =
        synchronized(lock) {
            (selectors +
                    if (strong) listOf("[id^='google_ads_']", "[data-ad-slot]", "ins.adsbygoogle")
                    else emptyList())
                .joinToString(",") +
                "{display:none!important;height:0!important;margin:0!important}"
        }

    companion object {
        val seed =
            """
! haider curated starter list; not the complete EasyList or EasyPrivacy
||doubleclick.net^
||googlesyndication.com^
||googleadservices.com^
||adservice.google.com^
||google-analytics.com^
||googletagmanager.com^
||connect.facebook.net^
||ads.twitter.com^
||adsystem.amazon.com^
||adnxs.com^
||adsrvr.org^
||scorecardresearch.com^
||taboola.com^
||outbrain.com^
##.adsbygoogle
##[data-ad-slot]
"""
                .trimIndent()

        fun host(url: String): String? =
            try {
                URI(url).host?.lowercase(Locale.ROOT)?.trimEnd('.')
            } catch (_: Exception) {
                null
            }

        fun matches(host: String, domain: String) = host == domain || host.endsWith(".$domain")

        fun parse(text: String): Parsed {
            val rules = mutableListOf<Rule>()
            val css = mutableListOf<String>()
            var skipped = 0
            text.lineSequence().take(200000).forEach { raw ->
                val line = raw.trim()
                when {
                    line.isEmpty() || line.startsWith("!") || line.startsWith("[") -> Unit
                    line.startsWith("##") &&
                        Regex("[a-zA-Z0-9_ .#\\[\\]='\"^*|:()\\-]+").matches(line.drop(2)) &&
                        !line.contains(":has") &&
                        !line.contains(":style") -> css.add(line.drop(2))
                    else -> {
                        val m =
                            Regex("^(@@)?\\|\\|([a-zA-Z0-9.-]+)\\^(?:\\$(third-party))?$")
                                .matchEntire(line)
                        if (
                            m != null &&
                                m.groupValues[2].contains('.') &&
                                !m.groupValues[2].startsWith('.')
                        )
                            rules.add(
                                Rule(
                                    m.groupValues[2].lowercase(Locale.ROOT),
                                    m.groupValues[1].isNotEmpty(),
                                    m.groupValues[3].isNotEmpty(),
                                )
                            )
                        else skipped++
                    }
                }
            }
            return Parsed(rules, css, skipped)
        }
    }
}
