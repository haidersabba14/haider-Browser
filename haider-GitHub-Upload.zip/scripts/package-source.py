#!/usr/bin/env python3
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path(__file__).resolve().parents[1]
output=root.parent/'artifacts/haider-Browser-Source.zip'
output.parent.mkdir(exist_ok=True)
with ZipFile(output,'w',ZIP_DEFLATED) as z:
 for p in sorted(root.rglob('*')):
  rel=p.relative_to(root)
  if not p.is_file() or any(part in {'.git','.gradle','.kotlin','.idea','build','dist','__pycache__'} for part in rel.parts) or p.name=='local.properties' or p.suffix in {'.jks','.keystore'}:continue
  z.write(p,'haider-Browser/'+str(rel))
print(output)
